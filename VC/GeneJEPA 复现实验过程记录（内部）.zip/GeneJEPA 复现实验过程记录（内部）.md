# GeneJEPA 复现实验过程记录（内部）

## **复现实验目标**



本次工作的目标不是直接加载 GeneJEPA 作者发布的预训练权重进行推理，而是**从随机初始化开始，自行训练一套缩小规模的 GeneJEPA，并完整跑通训练、验证和 checkpoint 保存流程**。



根据复现要求，最终确定的主要实验约束为：



- 数据：Tahoe\-100M；

\- 训练数据规模：原 training pool 的固定 **25%**；

- GeneJEPA latent blocks：`24 → 12`；

- attention heads：`12 → 6`；

- embedding dimension `d=768` 保持不变；

- latent 数量 `L=512` 保持不变；

- 不加载作者 checkpoint；

- 不使用作者预训练权重初始化；

- 从随机权重开始训练；

\- 重点观察 **validation loss curve**；

- 在正式训练前先完成单卡、双卡和小规模 smoke test。

这一实验原则在前期交接文档中也明确为：从随机初始化开始，用约 1/4 训练数据、`D=12`、`heads=6` 复现 GeneJEPA，并重点关注 validation loss。



**\-\-\-**



## **Tahoe\-100M 数据下载阶段**

### **遇到的问题：数据规模大、网络不稳定、重新连接代价高**



Tahoe\-100M 由大量 parquet shard 构成。GeneJEPA 使用的数据目录最终包含：



- `3388` 个 `data/*.parquet`；

- `gene_metadata.parquet`；

- 本地 `local_file_manifest.json`。

直接使用官方 `prepare_data()` 下载时，主要遇到两个问题：



1. 网络速度不稳定，需要能够自动判断长时间低速并重新连接；

2. 每次程序重启后，不希望再次从第 1 个文件开始逐个执行 `hf_hub_download()` 检查。

因此没有单纯依靠一次性的官方自动下载，而是在官方 DataModule 的基础上增加了下载 watchdog。



**\-\-\-**



### **下载脚本逐步改进**



最终形成了 `download_tahoe_watchdog_v3.py`。



主要改动包括：



**\#\#\# 断点记录**



程序维护：



```Plain Text
tahoe_download_plan.json
tahoe_download_state.json
tahoe_download_status.json
```



只有在：



- `hf_hub_download()` 正常返回；

- 最终文件真实存在；

- 文件大小有效；

- 如果远端 size 可用，则本地 size 与远端一致；

这些条件满足后，才把该文件登记为“完整下载”。



这样重新连接时可以直接从：



```Plain Text
next_data_index
```



继续，而不是重新从第一个 parquet 文件检查。



**\#\#\# 下载速度监控**



最终确定的低速判断逻辑为：



```Plain Text
每 15 秒计算一次实际新增数据对应的平均速度

连续 20 个 15 秒区间
= 连续 5 分钟

每个区间都 < 1 MiB/s
→ 自动断开并重连

只要任意一个区间 >= 1 MiB/s
→ 连续低速计数立即清零
```



而且只有真正处于 `downloading` 阶段时才测速，在本地文件检查、已有文件跳过等阶段不会错误触发低速重连。



最终下载程序能够：



```Plain Text
异常断开
  ↓
记录当前完成位置
  ↓
重新连接
  ↓
直接从下一个未完成 shard 继续
```



而不是重复遍历几千个已经完成的文件。



**\-\-\-**



## **数据完整性验证**

### **建立独立验证脚本**

下载完成以后，没有直接开始训练，而是增加：

```Plain Text
verify_tahoe.py
```



检查内容包括：



- manifest 是否存在；

- `data_files` 数量是否为 3388；

- metadata 是否存在；

- 下载 state 与 manifest 是否一致；

- parquet footer 是否可读取；

- deep 模式下读取 parquet row groups / 数据页。

验证脚本明确把 GeneJEPA 当前预期的 parquet shard 数固定为：



```Plain Text
EXPECTED_GENEJEPA_DATA_FILES = 3388
```



**\-\-\-**



### **发现一个损坏的 parquet**



虽然文件已经存在于磁盘上，但进一步完整扫描 validation parquet 时发现：



```Plain Text
train-00000-of-03388.parquet
```



无法正常反序列化 parquet page，出现类似：



```Plain Text
Couldn't deserialize thrift
TProtocolException: Invalid data
Deserializing page header failed
```



说明：



> “文件存在”或者“文件大小看起来正常”，并不能绝对证明 parquet 内部数据页完整。
> 
> 



处理方式是：



1. 定位损坏 shard；

2. 只重新下载这一份 parquet；

3. 替换原文件；

4. 再次执行 parquet 完整扫描；

5. 确认 validation 数据可以正常读取。

这一阶段也确定了一个后续原则：



> 长训练前应优先确认数据完整性，而不是等训练数小时后才因为坏 shard 崩溃。
> 
> 



**\-\-\-**



## **防止 GeneJEPA 重复下载数据**



下载完成后生成：



```Plain Text
hf_data_cache/local_file_manifest.json
```



随后确认：



```Plain Text
dm.prepare_data()
```



检测到 manifest 后会直接：



```Plain Text
Local file manifest found...
Skipping downloads.
```



所以后续训练不再重新访问 Hugging Face 下载整个 Tahoe\-100M。当前正式训练日志也确认继续使用本地 manifest。



因此从数据阶段结束以后，正式训练全部直接读取：



```Plain Text
hf_data_cache/
```



中的本地 parquet。



**\-\-\-**



## **第一次训练前的模型缩减**



原 GeneJEPA 模型规模较大，因此按照复现要求修改：



```Plain Text
d = 768
latents_L = 512

blocks_D = 12
heads_h = 6
```



主要只缩减：



```Plain Text
latent Transformer blocks
24 → 12

attention heads
12 → 6
```



其他关键结构参数尽量保持作者设置不变，例如：



```Plain Text
mask_ratio = 0.45
EMA start decay = 0.992
EMA end decay = 0.9995
EMA warmup steps = 2000

predictor_depth = 3
```



这样可以减少实验变量，让本次实验主要研究：



```Plain Text
缩小模型
+
缩小训练数据
```



而不是同时修改大量超参数。



**\-\-\-**



## **Global normalization statistics**



第一次训练时还没有：



```Plain Text
hf_data_cache/global_stats.json
```



因此 GeneJEPA 从训练文件中读取约 100 万个 cell 进行全局统计。



最终计算得到：



```Plain Text
mean ≈ 0.8255
std  ≈ 0.3135
```



整个统计过程涉及约：



```Plain Text
1,250,056,733 个 expression values
```



随后保存为：



```Plain Text
hf_data_cache/global_stats.json
```



后面的训练全部直接加载该文件，不再重复计算。



正式 25% 数据实验中，我们讨论过是否应该只使用 25% subset 重新计算 global mean/std。



最终决定：



> 保留原有的 global normalization statistics。
> 
> 



原因是它只作为固定的数据预处理统计量使用；这样不同实验之间 normalization 保持一致，只改变真正参与模型训练的数据规模。



因此当前实验口径应准确描述为：



> 模型训练使用固定 25% Tahoe training subset；表达值 normalization 使用此前计算得到的固定 Tahoe global statistics。
> 
> 



**\-\-\-**



## **单 GPU smoke test**



正式处理双 GPU 之前，首先用单张 RTX A6000 测试：



```Plain Text
CUDA_VISIBLE_DEVICES=0
```



smoke 配置大致为：



```Plain Text
batch_size = 92
train_samples = 1840
max_epochs = 1
validation_num_batches = 4

D = 12
heads = 6
```



单卡有效 batch size 为：



```Plain Text
92 × accumulate_grad_batches 2
= 184
```



训练能够完成：



```Plain Text
forward
backward
validation
checkpoint
```



证明：



> GeneJEPA 模型本身、Tahoe 数据、bf16、loss、Teacher EMA、validation 以及 checkpoint 流程在单卡环境下能够正常工作。
> 
> 



单卡成功以后，问题才被缩小到“双卡通信和 DDP”。



**\-\-\-**



## **双 GPU NCCL 问题**



硬件环境：



```Plain Text
2 × NVIDIA RTX A6000
约 48 GB VRAM / GPU
```



PyTorch：



```Plain Text
torch 2.7.1+cu126
CUDA available = True
```



但是进一步检查发现：



```Plain Text
torch.cuda.can_device_access_peer(0,1) = False
torch.cuda.can_device_access_peer(1,0) = False
```



同时：



```Plain Text
nvidia-smi topo -m
```



无法正常输出 topology matrix。



后来进一步确认服务器本身也没有安装物理 NVLink Bridge。



因此当前两张 A6000 并不能通过 NVLink/P2P 直接互联。



**\-\-\-**



### **NCCL 最小测试失败**



为了把“GeneJEPA 问题”和“GPU 通信问题”分离，我们单独编写了：



```Plain Text
/tmp/test_nccl.py
```



只执行最简单的：



```Plain Text
GPU0: x = 1
GPU1: x = 2

NCCL all_reduce

预期：
GPU0 = 3
GPU1 = 3
```



默认 NCCL 初始化失败：



```Plain Text
NCCL WARN Cuda failure 999 'unknown error'
include/alloc.h:237
```



即使只关闭：



```Plain Text
NCCL_CUMEM_HOST_ENABLE=0
```



仍然失败。



这说明问题不是 GeneJEPA 模型本身，因为最简单的 NCCL collective 都无法完成。



**\-\-\-**



### **NCCL 最终解决方案**



进一步关闭 NCCL device\-side cuMem allocation：



```Plain Text
NCCL_CUMEM_ENABLE=0
NCCL_CUMEM_HOST_ENABLE=0
```



之后 NCCL communicator 能够正常初始化，并完成：



```Plain Text
1 + 2 → all_reduce → 3
```



因此当前双卡训练固定使用：



```Plain Text
NCCL_CUMEM_ENABLE=0
NCCL_CUMEM_HOST_ENABLE=0
```



作为当前：



```Plain Text
WSL
+
PyTorch 2.7.1
+
NCCL 2.26.x
+
2 × A6000
```



环境的兼容性 workaround。



当前没有使用 NVLink/P2P，而由 NCCL 使用可用的 fallback 通信路径。



**\-\-\-**



## **双卡 DDP 的第二个问题：Hugging Face IterableDataset\.shard\(\)**



NCCL 解决以后，Lightning DDP 已经能够初始化，但又出现新的报错：



```Plain Text
AttributeError:
'IterableDataset' object has no attribute 'shard'
```



问题来自原来的 DDP 数据分片代码：



```Plain Text
hf_dataset = hf_dataset.shard(
    num_shards=world_size,
    index=rank
)
```



实际环境中的 Hugging Face：



```Plain Text
datasets = 2.19.2
```



这个版本的：



```Plain Text
datasets.IterableDataset
```



没有公开 `.shard()` 方法。



**\-\-\-**



### **解决方式：在 parquet 文件列表层做 DDP 分片**



不再创建 IterableDataset 后调用：



```Plain Text
hf_dataset.shard(...)
```



而是先按 rank 分 parquet 文件：



```Plain Text
file_list = file_list[rank::world_size]
```



再分别：



```Plain Text
load_dataset(
    "parquet",
    data_files=file_list,
    streaming=True
)
```



逻辑变成：



```Plain Text
training parquet files
        ↓
DDP rank-level split
     ↙       ↘
rank 0      rank 1
  ↓           ↓
GPU0         GPU1
```



最终双卡 smoke test 能够正常完成训练和验证。当前 `data.py` 也继续采用这种 rank\-level 文件分片方法。



**\-\-\-**



## **正式定义“25% training data”**



最开始需要解决的一个实验设计问题是：



> “1/4 数据”究竟应该理解为少跑 1/4 steps，还是实际固定 1/4 数据集？
> 
> 



最终决定：



> 真实固定 training data pool，而不是仅仅减少 `train_samples`。
> 
> 



当前 Tahoe 划分为：



```Plain Text
总 parquet shards = 3388

validation = 16
training pool = 3372
```



所以 training pool 的严格 25% 为：



```Plain Text
3372 / 4
= 843 shards
```



因此：



```Plain Text
16 个 validation shards
保持固定

从 3372 个 training shards 中
用 seed=42 一次性选出 843 个
```



并把结果保存为：



```Plain Text
hf_data_cache/train_subset_quarter_seed42.json
```



之后所有正式实验都读取这同一份 manifest，而不是每次启动时重新随机抽 25%。



`data.py` 会验证：



- validation shard 是否仍与冻结 manifest 一致；

- selected training files 是否全部属于 training pool；

- 是否有重复 shard；

- 最终 training subset 是否正确加载。

当前正式训练日志已经确认：



```Plain Text
Fixed training subset enabled:
843/3372 shards (25.00%)
```



**\-\-\-**



## **修复训练数据 shuffle 的可重复性**



原代码使用：



```Plain Text
shuffle_seed = int(time.time()) + rank
```



这意味着：



> 即使实验都写着 random seed=42，只要启动时间不同，训练数据顺序仍会改变。
> 
> 



对于正式复现不够严谨。



因此改为：



```Plain Text
shuffle_seed = random_seed + epoch
```



即：



```Plain Text
epoch 0 → seed 42
epoch 1 → seed 43
epoch 2 → seed 44
...
```



并设置：



```Plain Text
reload_dataloaders_every_n_epochs=1
```



保证每个 epoch 重新创建 DataLoader，从而让新的 epoch seed 真正生效。



当前代码会显式输出：



```Plain Text
Train shuffle:
epoch=X
seed=42+X
rank=...
```



随后专门运行 2\-epoch smoke test，确认：



```Plain Text
epoch 0 → seed 42
epoch 1 → seed 43
```



并且两个 epoch 均正常完成 train、validation 和 checkpoint。



**\-\-\-**



## **DataLoader worker 性能问题**



正式训练初期观察：



```Plain Text
GPU utilization：
100% → 0% → 100% → 0%
```



同时日志提示：



```Plain Text
train_dataloader does not have many workers
```



进一步检查发现：



虽然：



```Plain Text
DataConfig.num_workers = 8
```



但实际 DataLoader 被代码强制设置成：



```Plain Text
num_workers = 0
```



也就是说 GPU 在训练过程中可能需要等待 CPU 读取、解析和 collate 下一批 Tahoe 数据。



**\-\-\-**



## **Hugging Face worker 分片兼容性**



当前：



```Plain Text
datasets version = 2.19.2
```



检查发现：



```Plain Text
IterableDataset.has shard = False
```



但 Hugging Face 自身的 `IterableDataset.__iter__()` 已经会读取：



```Plain Text
get_worker_info()
worker_info
```



因此：



> HF 2\.19\.2 会自己处理 DataLoader worker 的 streaming shard 分配，没有必要再手动执行 `dataset_instance.shard()`。
> 
> 



所以删除了自定义 worker `.shard()` 逻辑，让 Hugging Face 内部负责 worker\-level sharding。当前 `Tahoe100MDataset.__iter__()` 就采用这一方式。



**\-\-\-**



## **将实际 worker 数改为运行时参数**



为了避免每次测试不同 worker 数都修改 Python 文件，增加：



```Plain Text
GENEJEPA_TRAIN_WORKERS=N
```



例如：



```Plain Text
GENEJEPA_TRAIN_WORKERS=2
```



实际 DataLoader worker 由环境变量决定。



而：



```Plain Text
DataConfig.num_workers = 8
```



仍然保留。



这里有一个当前代码设计上的特殊点：



```Plain Text
DataConfig.num_workers=8
```



不仅代表 worker 配置，还参与：



```Plain Text
min_files_for_parallelism = num_workers * 2
```



从而影响 validation shard 数。



因此目前：



```Plain Text
DataConfig.num_workers = 8
```



主要继续用于保持：



```Plain Text
validation = 16 shards
```



而真正训练时的 DataLoader worker 数由：



```Plain Text
GENEJEPA_TRAIN_WORKERS
```



控制。



这是目前代码中两个需要明确区分的概念。



**\-\-\-**



## **Worker benchmark**



为了确定实际最佳 worker 数，不直接凭经验使用 8，而是进行了：



```Plain Text
0 / 2 / 4 / 8 workers
```



四组 benchmark。



每组统一：



```Plain Text
200 raw training batches
1 epoch
2 GPUs
batch_size=92
相同模型
相同数据
相同随机种子
```



结果大致为：



|Training workers200 batch 时间稳态吞吐|||
|---|---|---|
|0|≈10:01|≈0\.379 batch/s|
|2|≈8:50|≈0\.439 batch/s|
|4|≈9:04|≈0\.435 batch/s|
|8|≈9:05|≈0\.431 batch/s|



从 `0 → 2` 后吞吐提高约 16%，说明之前 DataLoader 确实是 GPU 等待的重要原因之一。



但继续增加到 4、8 并没有进一步提高速度。



因此正式训练选择：



```Plain Text
GENEJEPA_TRAIN_WORKERS=2
```



worker=2 benchmark 使用了固定的 843/3372 subset 和双 GPU 配置。

worker=4 和 worker=8 也进行了相同条件下的测试。

worker=0 则作为 baseline。



**\-\-\-**



## **persistent\\\_workers 与跨 epoch reload**



多 worker benchmark 时 Lightning 提示：



```Plain Text
persistent_workers=True
+
reload_dataloaders_every_n_epochs=1
```



可能导致长期训练不稳定。



正式训练又必须保留：



```Plain Text
reload_dataloaders_every_n_epochs=1
```



因为需要实现：



```Plain Text
epoch 0 seed=42
epoch 1 seed=43
...
```



因此最终修改为：



```Plain Text
persistent_workers=False
prefetch_factor=2
```



然后专门运行 2\-epoch worker=2 smoke test。



结果确认：



```Plain Text
Epoch 0
worker=2
seed=42

Epoch 1
重新创建 DataLoader
worker=2
seed=43
```



两轮均正常结束。



至此 DataLoader 方案冻结。



**\-\-\-**



## **一次 validation split 不一致问题**



在 worker 调试过程中曾将：



```Plain Text
DataConfig.num_workers
```



误改为 `2`。



由于原代码存在：



```Plain Text
min_files_for_parallelism
=
DataConfig.num_workers * 2
```



validation 于是从：



```Plain Text
16 shards
```



变成：



```Plain Text
4 shards
```



固定的 25% manifest 检查立即报错：



```Plain Text
Validation shard list does not match
the frozen subset manifest.
```



这个报错反而证明数据冻结检查正常工作，没有允许实验数据划分悄悄改变。



最终明确：



```Plain Text
DataConfig.num_workers = 8
→ 保持 16 validation shards

GENEJEPA_TRAIN_WORKERS = 2
→ 实际训练 DataLoader workers
```



两者不能混淆。



**\-\-\-**



## **最初 Formal Run 1 配置（后续已调整）**



经过全部 smoke test 和性能测试后，Formal Run 1 最终配置为：



**\#\# 模型**



```Plain Text
d = 768
latents_L = 512
blocks_D = 12
heads_h = 6

mask_ratio = 0.45

EMA:
start = 0.992
end = 0.9995
warmup = 2000 steps
```



**\#\# 训练**



```Plain Text
batch_size = 92 / GPU
GPU 数 = 2
gradient accumulation = 2

effective batch size
= 92 × 2 × 2
= 368

learning_rate = 1e-4
weight_decay = 2e-4
max_epochs = 50
```



**\#\# 数据**



```Plain Text
固定 validation = 16 shards

原 training pool = 3372 shards

正式 training subset
= 843 shards
= 25%

subset:
train_subset_quarter_seed42.json
```



**\#\# 每 epoch 训练预算**



```Plain Text
train_samples = 1,000,000
```



双卡对应：



```Plain Text
5435 raw batches / epoch

2718 optimizer updates / epoch

50 epochs
→ 135900 optimizer updates
```



正式训练日志已确认这一 schedule。



**\#\# Validation**



```Plain Text
validation_num_batches = 55
```



大约对应：



```Plain Text
92 × 2 GPUs × 55
≈ 10,120 validation cells
```



即与目标的约 10k validation samples 数量级基本对应。



**\#\# DataLoader**



```Plain Text
GENEJEPA_TRAIN_WORKERS = 2

persistent_workers = False
prefetch_factor = 2

validation num_workers = 0
```



**\#\# 计算**



```Plain Text
2 × NVIDIA RTX A6000
bf16 mixed precision
```



**\#\# NCCL**



```Plain Text
NCCL_CUMEM_ENABLE=0
NCCL_CUMEM_HOST_ENABLE=0
```



**\#\# W\&B**



当前使用：



```Plain Text
WANDB_MODE=offline
```



**\#\# Checkpoint**



正式目录：



```Plain Text
checkpoints/
genejepa_quarter_d12_h6_seed42_run1
```



并在正式启动前确保不存在需要自动 resume 的旧 checkpoint，从随机初始化开始训练。



**\-\-\-**



## **Formal Run 1 启动命令**



当前正式训练使用：



```Plain Text
GENEJEPA_TRAIN_WORKERS=2 \
CUDA_VISIBLE_DEVICES=0,1 \
NCCL_CUMEM_ENABLE=0 \
NCCL_CUMEM_HOST_ENABLE=0 \
WANDB_MODE=offline \
uv run -m genejepa.train \
2>&1 | tee logs/genejepa_quarter_d12_h6_seed42_run1.log
```



当前日志已经确认：



```Plain Text
2 devices detected

effective batch size = 368

16 validation shards

3372 original training shards

843/3372 fixed training subset
= 25%

5435 raw batches/epoch

2718 optimizer updates/epoch

135900 total optimizer updates

55 validation batches
```



并已经正式进入训练。



**\-\-\-**



## **到8\.13为止实际解决的问题总结**



整个 GeneJEPA 复现过程中已经依次处理了：





2. 网络断开后重复从第一个文件检查；

3. 下载进度无法可靠记录；

4. 下载测速把“检查已有文件”误判为低速；

5. 下载完成以后缺少系统性 parquet 完整性检查；

6. 检出并重新下载损坏 parquet；

7. 防止 GeneJEPA 训练阶段重新下载 Tahoe；

8. 第一次生成 global normalization statistics；

9. 完成单 GPU smoke test；

10. 双 GPU NCCL CUDA 999；

11. WSL 下两卡 P2P 不可用；

12. 使用 `NCCL_CUMEM_ENABLE=0` workaround 打通 NCCL；

13. Hugging Face `IterableDataset.shard()` API 不兼容；

14. 改成 DDP rank\-level parquet 文件分片；

15. 成功完成双 GPU smoke test；

16. 明确定义“25% training data”；

17. 固定 843 个 training shards；

18. 固定 16 个 validation shards；

19. 修复依赖启动时间的 shuffle；

20. 实现 `seed + epoch` 可复现 shuffle；

21. 验证跨 epoch DataLoader reload；

22. 发现 `num_workers=0` 带来的 GPU 等数据问题；

23. 修复 HF streaming 多 worker 兼容；

24. 增加 `GENEJEPA_TRAIN_WORKERS` 运行时参数；

25. benchmark 0/2/4/8 workers；

26. 最终确定 training workers=2；

27. 处理 `persistent_workers` 与 epoch reload 的兼容问题；

28. 运行 2\-epoch 跨 epoch smoke；

29. 恢复 50 epoch Formal Run 1；

30. 当前正式进入 GeneJEPA 复现训练阶段。

**\-\-\-**



## **截至 2026\-08\-13 的阶段状态（历史记录）**



截至目前，环境和训练基础设施已经基本冻结。



状态可以概括为：



```Plain Text
Tahoe 数据下载                 ✅
数据完整性验证                 ✅
本地 manifest                  ✅
单卡训练                       ✅
双卡 NCCL                      ✅
双卡 DDP                       ✅
固定 25% training subset       ✅
固定 validation                ✅
随机初始化                     ✅
可复现 epoch shuffle           ✅
DataLoader worker benchmark    ✅
跨 epoch worker 验证           ✅
正式 50 epoch Run 1            ▶ 正在进行
```



接下来工作的重点已经不再是“代码是否能运行”，而应该转向模型训练本身。



**\-\-\-**



## **后续重点记录内容**



Formal Run 1 后续需要重点保存和分析：



### **Validation loss curve**



每个 epoch 记录：



```Plain Text
epoch
val_loss
```



最终绘制完整 50 epoch 曲线。



重点观察：



- validation loss 是否持续下降；

- 哪个 epoch 达到最低值；

- 是否进入平台期；

- 后期是否回升；

- 是否有明显过拟合；

- EMA warmup 前后曲线是否发生变化。

### **Train loss curve**



同步记录：



```Plain Text
train/loss
train_loss/sim
```



观察 train 与 validation 是否一致。



### **EMA warmup**



当前：



```Plain Text
ema_warmup_steps = 2000
```



而正式训练：



```Plain Text
2718 optimizer updates / epoch
```



因此第一个 epoch 内就会跨过 Teacher EMA warmup。



需要特别关注：



```Plain Text
前 2000 step
和
warmup 后
```



模型行为是否存在明显变化。



### **Checkpoint**



需要保存：



```Plain Text
best checkpoint
last checkpoint
```



并记录：



```Plain Text
best checkpoint 对应 epoch
best val_loss
```



### **异常监控**



正式训练过程中真正需要警惕的是：



```Plain Text
NaN
Inf
CUDA OOM
NCCL error
DataLoader worker exited
parquet read error
loss 突然异常爆炸
```



普通 Lightning 性能 warning 暂时不作为中断训练的理由。



**\-\-\-**



## **截至 2026\-08\-13 的阶段性一句话总结（历史记录）**



本次工作已经从最初的：



```Plain Text
“先让 GeneJEPA 能跑起来”
```



逐步完成了：



```Plain Text
Tahoe-100M 本地化
→ 数据完整性验证
→ 单卡训练
→ 双卡 NCCL 修复
→ DDP 数据分片修复
→ 固定 25% 数据集
→ 可复现 shuffle
→ DataLoader 性能优化
→ 多 epoch 验证
```



目前已经进入：



\> **2×RTX A6000、D=12、heads=6、固定 Tahoe training pool 25%、随机初始化、50 epochs 的 GeneJEPA Formal Run 1。**



从现在开始，实验的核心评价对象是 **validation loss curve 和最终 checkpoint**，而不再是训练环境是否能够正常启动。

**\-\-\-**



## **8\.14重新评估训练时长：没必要把 25% dataset 直接改成 10%**



最初 Formal Run 1 的配置为：



```Plain Text
固定 25% training subset
train_samples = 1,000,000 / epoch
max_epochs = 50
```



启动后根据实际速度估算，完整跑完约需要两周。领导认为耗时过长，最初提出：



> 是否可以把训练数据从 25% 直接缩减到 10%。
> 
> 



在进一步梳理训练代码后，发现当前 GeneJEPA 工程里的 `epoch` 并不是“完整遍历一次训练数据集”的传统定义，而是通过 `train_samples` 人为限制每个 epoch 的训练样本预算。



代码中的核心关系为：



```Python
steps_per_epoch = ceil(
    train_samples / (batch_size * num_devices)
)
```



然后 Trainer 使用：



```Python
limit_train_batches = steps_per_epoch
```



因此：



```Plain Text
dataset/subset 比例
    ↓
决定模型允许从多大的数据池中取样

train_samples
    ↓
决定每个 epoch 实际处理多少 cell

max_epochs
    ↓
决定总共重复多少个训练周期
```



这意味着，只要缩减后的 subset 仍然足够提供每个 epoch 所要求的样本数量，那么：



```Plain Text
25% dataset
→ 每 epoch 仍处理 1,000,000 cells

10% dataset
→ 如果 train_samples 仍然是 1,000,000
→ 每 epoch 仍然处理约 1,000,000 cells
```



GPU 需要执行的 raw batch 数不会按 `25% → 10%` 的比例下降。



因此最终没有为了“提速”直接牺牲训练数据多样性，而是保留固定 25% training subset，改为直接减少训练预算。



这个阶段形成了一个重要认识：



\> **\*\*dataset percentage 主要控制数据多样性；\`train\_samples\` 和 \`max\_epochs\` 才是当前工程中更直接控制训练计算量和总时长的参数。\*\***



另外，当前每个 epoch 的样本并不是先对整个训练池做一次严格的 `random.sample(1,000,000)`。实际数据管线是：



```Plain Text
固定 training subset
→ HF streaming dataset
→ shuffle buffer = 50,000
→ seed = random_seed + epoch
→ 从打乱后的 streaming 数据流中持续读取
→ 达到该 epoch 的 train_samples / raw-batch 上限后停止
```



因此可以近似理解为“每个 epoch 从固定数据池中经过随机打乱后取一段训练样本”，但不是对全池一次性做严格均匀无放回抽样。



**\-\-\-**



## **训练单位重新梳理：sample、batch、raw batch、optimizer update、epoch**



为了后续能够正确判断训练规模，重新明确了当前工程中各单位的关系。



### **Sample**



当前任务中可以近似理解为：



```Plain Text
1 sample = 1 cell
```



**\-\-\-**



### **Per\-GPU batch size**



当前：



```Plain Text
batch_size = 92
```



这里的 92 是 **每张 GPU 一次处理的 cell 数量**。



因此：



```Plain Text
GPU0 → 92 cells
GPU1 → 92 cells
```



**\-\-\-**



### **Raw batch**



双卡同时完成一次训练迭代时：



```Plain Text
92 × 2 GPUs
= 184 cells
```



在当前记录中，把这一次两卡并行训练迭代称为：



```Plain Text
1 raw batch = 184 cells
```



**\-\-\-**



### **Gradient accumulation 与 optimizer update**



当前：



```Plain Text
accumulate_grad_batches = 2
```



因此不是每个 raw batch 都立即更新模型参数，而是：



```Plain Text
raw batch #1
184 cells
→ forward/backward
→ 梯度先保留

raw batch #2
184 cells
→ forward/backward
→ 梯度继续累积

两次梯度合并
→ optimizer.step()
→ 真正更新一次参数
```



所以：



```Plain Text
1 optimizer update
≈ 2 raw batches
≈ 368 cells
```



当前 effective batch size 因此为：



```Plain Text
92 per GPU
× 2 GPUs
× 2 gradient accumulation
= 368
```

**\-\-\-**



## **技术顾问关于训练加速的建议，以及当前工程实际使用的技术**



训练时间过长后，技术顾问主要提出了以下方向：



1. `gradient accumulation`；

2. DeepSpeed 或 Hugging Face Accelerate；

3. 确认是否使用 BF16；

4. 确认 batch size；

5. 后续建议接 TensorBoard，边训练边看 validation/test loss curve；

6. 认为 50 epochs 可能也没有必要全部跑满。

在讨论这些建议时，也重新明确了当前项目的训练技术栈。



### **PyTorch Lightning**



当前 GeneJEPA 工程并不是直接用裸 PyTorch 手工管理整个训练循环，而是：



```Plain Text
GeneJEPA model
    ↓
PyTorch
    ↓
PyTorch Lightning
    ↓
DDP
    ↓
GPU0 + GPU1
```



Lightning 目前负责管理：



- 多 GPU；

- DDP；

- BF16 mixed precision；

- gradient accumulation；

- optimizer / scheduler；

- epoch；

- validation；

- checkpoint；

- logger。

因此顾问提到的“gradient accumulation 几行代码”在当前工程中不需要再手工实现，Lightning 已经提供对应参数。



**\-\-\-**



### **Gradient accumulation 已经启用**



当前：



```Plain Text
accumulate_grad_batches = 2
```



因此 gradient accumulation 已经实际运行并经过多轮 smoke / formal training 验证。



需要注意：



> 当前只能说“已经启用并验证可以正常工作”，并没有专门 benchmark `accumulation=1/2/4` 谁更快。
> 
> 



因此后续对外描述应为：



```Plain Text
Gradient accumulation 已启用，当前设置为 2。
尚未单独做不同 accumulation 值的速度对比。
```



**\-\-\-**



### **BF16**



当前硬件与日志已经明确：



```Plain Text
Hardware support for bfloat16: True
Using precision: 'bf16-mixed'
```



因此当前正式训练使用：



```Plain Text
BF16 mixed precision
```



它不是把所有计算强制变成 BF16，而是由混合精度机制让适合的计算使用 BF16，同时部分需要数值稳定性的计算仍可保留更高精度。



**\-\-\-**



### **Batch size 的完整表述**



如果只问代码配置：



```Plain Text
batch_size = 92
```



但在双卡 \+ gradient accumulation 场景下，更完整的描述应该是：



```Plain Text
Per-GPU batch size = 92

Global raw batch
= 92 × 2 GPUs
= 184

Gradient accumulation = 2

Effective batch size
= 92 × 2 × 2
= 368
```



因此后续与技术顾问沟通时，推荐直接描述为：



> `batch size=92 per GPU，2 GPUs，gradient accumulation=2，因此 effective batch size=368。`
> 
> 



**\-\-\-**



### **DeepSpeed / Accelerate**



当前正式训练使用的是：



```Plain Text
PyTorch Lightning + DDP
```



尚未切换到：



```Plain Text
DeepSpeed
```



也没有把整个训练框架迁移到：



```Plain Text
Hugging Face Accelerate
```



考虑到 Lightning 本身支持 DeepSpeed strategy，因此后续如果专门做性能优化，更合理的实验是：



```Plain Text
Lightning + 当前 DDP
vs
Lightning + DeepSpeed
```



做短 benchmark，而不是为了使用 Accelerate 重写整个训练工程。



当前阶段由于首要目标变成“先完成本次复现训练”，因此 DeepSpeed / Accelerate 暂未实际 benchmark 或用于正式训练。



这里的 `benchmark` 指“保持其他条件尽量一致，只改变一个待比较因素，然后比较速度/吞吐/稳定性”。前面已经实际做过的 `num_workers=0/2/4/8` 对比，本质上就是一次 DataLoader benchmark。



**\-\-\-**



## **TensorBoard 接入与 validation loss 可视化**



技术顾问提出：



> 如果仍需要跑较多 epoch，希望增加 TensorBoard 支持，这样可以边跑边看实际 validation 或 test loss curve，而不是等全部训练结束以后再判断模型是否已经收敛。
> 
> 



当前 GeneJEPA 代码本身已经存在 validation loss 计算，因此主要工作是增加 TensorBoard logger，而不是重新设计 validation。



**\-\-\-**



### **TensorBoard 环境确认**



当前环境：



```Plain Text
TensorBoard 2.20.0
```



运行时有：



```Plain Text
TensorFlow installation not found - running with reduced feature set.
```



但当前项目是 PyTorch / Lightning，目标只是查看 scalar 曲线，因此没有为此额外安装 TensorFlow。



启动方式：



```Bash
uv run tensorboard \
  --logdir logs/tensorboard \
  --port 6006
```



浏览器访问：



```Plain Text
http://localhost:6006
```



**\-\-\-**



### **Lightning 同时使用 W\&B 与 TensorBoard**



原来只使用：



```Python
WandbLogger
```



后续增加：



```Python
TensorBoardLogger
```



并将 Trainer logger 改为 logger list，使两个 logger 可以同时接收 Lightning 的 `self.log(...)` 指标。



结构变为：



```Plain Text
Lightning metrics
      ↓
  ┌───┴────┐
  ↓        ↓
W&B    TensorBoard
```



W\&B 继续保持：



```Plain Text
WANDB_MODE=offline
```



TensorBoard 则用于本地实时看训练曲线。



**\-\-\-**



### **清理重复的 validation loss 指标**



最初 `validation_step()` 中，同一个 `val_sim` 同时记录为：



```Plain Text
val/loss
val_loss
val_loss/sim
```



因此 TensorBoard 中出现多个数值完全相同的 card。



后续将核心 validation 指标统一为：



```Plain Text
val_loss
```



同时显式提供真实 batch size：



```Python
self.log(
    "val_loss",
    val_sim,
    on_step=False,
    on_epoch=True,
    prog_bar=True,
    sync_dist=True,
    batch_size=batch_size,
)
```



这样：



- TensorBoard 中只需要关注一个核心 `val_loss`；

- checkpoint 继续监控同一个 `val_loss`；

- 避免 Lightning 从 ragged batch 结构中错误猜测 batch size。

**\-\-\-**



### **TensorBoard smoke test**



为了验证 TensorBoard 链路，使用过短规模 smoke：



```Plain Text
max_epochs = 3
train_samples = 1840
10 raw batches / epoch
5 optimizer updates / epoch
log_every_n_steps = 1
```



结果确认：



- TensorBoard 页面可以正常打开；

- `val_loss` 可以正常显示；

- 多个 epoch 后 `val_loss` 确实呈下降趋势；

- TensorBoard 与 Lightning validation 链路已经打通。

因此随后恢复正式训练时，将：



```Plain Text
log_every_n_steps = 1
```



恢复为：



```Plain Text
log_every_n_steps = 10
```



避免正式训练阶段过于频繁地写日志。



**\-\-\-**



## **正式训练预算从 1M×50 调整为 700k×30**



在明确“dataset 比例”和“训练预算”不是同一个概念以后，最终没有把固定训练数据池从 25% 降到 10%。



正式训练保留：



```Plain Text
Fixed training subset:
843 / 3372 shards
= 25%
```



但训练预算调整为：



```Plain Text
train_samples = 700,000
max_epochs = 30
```



其他核心模型参数保持：



```Plain Text
d = 768
latents_L = 512
blocks_D = 12
heads_h = 6

batch_size = 92
accumulate_grad_batches = 2
```



Validation 恢复正式规模：



```Plain Text
validation_num_batches = 55
```



正式 run 名称：



```Plain Text
GeneJEPA-quarter-d12-h6-700k-e30-seed42-run1
```



checkpoint 目录：



```Plain Text
checkpoints/
genejepa_quarter_d12_h6_700k_e30_seed42_run1
```



正式启动前曾通过配置打印检查发现 `checkpoint_dir` 仍误指向 TensorBoard smoke 目录：



```Plain Text
checkpoints/genejepa_tensorboard_smoke_v2
```



随后改为全新的正式目录，避免正式 run 意外从 smoke checkpoint 恢复。这个检查再次确认了长训练前“必须使用独立 checkpoint 目录”的原则。



**\-\-\-**



### **新训练计划换算**



每个 epoch：



```Plain Text
700,000 / (92 × 2 GPUs)
≈ 3805 raw batches / epoch
```



梯度累积：



```Plain Text
3805 / 2
≈ 1903 optimizer updates / epoch
```



30 个 epoch：



```Plain Text
1903 × 30
= 57090 total optimizer updates
```



正式日志实际打印：



```Plain Text
3805 raw batches/epoch
1903 optimizer updates/epoch
57090 total updates over 30 epochs
```



**\-\-\-**



### **相比原 50×1M 的工作量变化**



原计划：



```Plain Text
1,000,000 × 50
= 50,000,000 cell-processing budget
```



新计划：



```Plain Text
700,000 × 30
= 21,000,000 cell-processing budget
```



比例：



```Plain Text
21M / 50M
= 42%
```



因此新方案的主要训练计算预算约为原方案的：



```Plain Text
42%
```



即粗略减少：



```Plain Text
约 58%
```



这比单纯把 dataset 从 25% 改成 10% 更直接地缩短了训练时长，同时保留了原固定 25% 数据池的数据多样性。



**\-\-\-**



## **正式训练中的 DDP 数据分流和 DataLoader worker 状态**



正式 700k×30 训练中再次确认了双卡数据分流仍然存在。



训练数据：



```Plain Text
843 fixed training shards
```



DDP 分配：



```Plain Text
rank 0 / GPU0
→ 422 / 843 parquet files

rank 1 / GPU1
→ 421 / 843 parquet files
```



Validation：



```Plain Text
16 validation shards

rank 0
→ 8 / 16

rank 1
→ 8 / 16
```



因此两张 GPU 并不是重复读取完全相同的一整套 parquet，而是在文件列表层先做 disjoint DDP rank sharding，再分别建立 streaming dataset。



**\-\-\-**



### **Training workers**



启动时继续使用：



```Bash
GENEJEPA_TRAIN_WORKERS=2
```



它的实际含义是：



```Plain Text
每个 DDP rank / 每张 GPU
使用 2 个 DataLoader workers
```



因此整个双卡作业实际共有：



```Plain Text
rank0 → 2 workers
rank1 → 2 workers

总计 4 个 worker 子进程
```



而：



```Plain Text
DataConfig.num_workers = 8
```



继续保留，主要用于维持当前 validation split 逻辑中的 16 个 validation shards，并不等于正式训练实际启用了 8 个 training workers。



Validation workers 仍保持：



```Plain Text
0
```



以优先保证 streaming validation 稳定。



**\-\-\-**



### **GPU utilization 波动**



正式训练时观察到某张 GPU 会在：



```Plain Text
100%
→ 0%
→ 再回到 100%
```



之间波动。



由于：



- 每个 cell 有效基因数量不同；

- ragged batch 的实际计算量不同；

- DDP 两个 rank 在梯度同步点需要互相等待；

- 当前机器双卡无 P2P / NVLink；

因此瞬时 GPU utilization 波动不能单独证明“数据没有分流”。



日志已经确认 DDP shard 分流仍然正常。



**\-\-\-**



## **正式训练第一次长期 CUDA 崩溃与 checkpoint resume**



正式训练在已经运行多个 epoch 后第一次出现长期运行阶段 CUDA 崩溃。



典型位置：



```Plain Text
Epoch 9
1819 / 3805
≈ 48%
```



错误首先出现在：



```Plain Text
rank1
CUDA warning: unknown error
CUDA error: unknown error
```



随后 rank1 退出，Lightning/DDP 强制结束另一个进程。



这不是正常训练结束。



**\-\-\-**



### **Checkpoint 保留情况**



崩溃后 checkpoint 目录中确认存在：



```Plain Text
last.ckpt

scjepa-epoch=04-val_loss=0.433.ckpt
scjepa-epoch=08-val_loss=0.345.ckpt
```



说明至少 Epoch 0～8 的完整训练结果已经保住。



重新启动原 run 后，日志明确出现：



```Plain Text
Resuming from checkpoint: .../last.ckpt
Loaded EMA teacher state from checkpoint.
Restored all states from the checkpoint ...
```



随后重新进入：



```Plain Text
Epoch 9
```



因此 checkpoint resume 已经实际验证有效，恢复的不只是模型权重，还包括 Lightning checkpoint 中的训练状态。



不过由于原 `last.ckpt` 主要在完整 epoch 结束后保存，因此 Epoch 9 已经跑过但尚未完成的部分需要重新训练。



**\-\-\-**



### **TensorBoard version 分段**



每次重新启动 run 时，TensorBoardLogger 会建立新的：



```Plain Text
version_0
version_1
version_2
...
```



所以 TensorBoard 页面中同一次模型训练的不同 resume 阶段可能显示为不同 run/version。



这只是日志目录分段，不代表模型从随机初始化重新开始。



**\-\-\-**



## **CUDA 错误重复出现：Epoch 15 多次重跑**



后续训练再次发生低层 CUDA failure。



典型错误包括：



```Plain Text
rank1
CUDA warning: unspecified launch failure
CUDA error: unspecified launch failure
```



而且多次都是 rank1 先失败。



不同重试中崩溃位置并不固定，例如曾出现：



```Plain Text
Epoch 15
约 1469 / 3805
```



以及：



```Plain Text
Epoch 15
约 590 / 3805
```



因此它不像“某一个固定 batch 每次必然触发错误”，更像长期双卡运行环境中的 CUDA / GPU / WSL / DDP 稳定性问题。



本阶段没有继续优先追查根因，因为工作目标临时调整为：



\> **先尽可能把本次复现训练完成。**



**\-\-\-**



### **模型指标在崩溃前并没有明显发散**



崩溃期间训练 loss 并没有出现 NaN / Inf 爆炸。



已保存 checkpoint 的 validation loss 例如：



```Plain Text
epoch 4  → val_loss = 0.433
epoch 8  → val_loss = 0.345
```



后续运行中又观察到：



```Plain Text
val_loss ≈ 0.299
```



说明在 CUDA 崩溃发生的同时，模型 validation loss 仍在继续下降。



因此当前更倾向于把“模型优化状态”和“底层 CUDA 稳定性”分开看待。



**\-\-\-**



## **增加自动崩溃重启脚本 auto\_resume\_genejepa\.sh**



由于 CUDA 错误发生时间不可预测，而且人工重新启动会浪费大量等待时间，因此在训练命令外层增加：



```Plain Text
auto_resume_genejepa.sh
```



核心逻辑：



```Plain Text
启动 GeneJEPA
    ↓
正常结束
→ 脚本退出

异常退出
→ 获取真实训练进程 exit code
→ 记录 nvidia-smi
→ 等待 60 秒
→ 自动重新执行 GeneJEPA
→ train.py 自动发现 last.ckpt
→ resume
```



**\-\-\-**



### **关键：使用 PIPESTATUS 获取真实退出码**



由于训练命令通过：



```Bash
uv run -m genejepa.train \
2>&1 | tee -a ...
```



写日志，如果简单读取 `$?`，得到的可能是 `tee` 的退出状态，而不是 Python 训练进程的状态。



因此脚本使用：



```Bash
exit_code=${PIPESTATUS[0]}
```



确保能够检测到真正的 CUDA crash。



**\-\-\-**



### **自动重试策略**



脚本配置：



```Plain Text
RETRY_DELAY = 60 s
MAX_RETRIES = 20
```



每次异常退出后：



1. 记录 crash 时间；

2. 记录 `nvidia-smi`；

3. 等待 60 秒；

4. 重新启动训练；

5. 同一个 checkpoint 目录继续使用。

日志已经实际出现：



```Plain Text
Starting training attempt 1
```



发生 CUDA crash 后又自动进入：



```Plain Text
Starting training attempt 2
```



并成功再次从 `last.ckpt` 恢复训练。



因此：



\> **“训练异常退出 → 自动重启 → checkpoint resume”这条链路已经实际验证可工作。**



**\-\-\-**



## **为什么 Epoch 15 会反复从头重跑：增加 mid\-epoch recovery checkpoint**



虽然自动重启已经有效，但出现了新的实际问题：



```Plain Text
Epoch 15 跑了一部分
→ CUDA crash
→ last.ckpt 仍是 Epoch 14 结束时
→ 自动 resume
→ Epoch 15 从 0/3805 重新开始
```



如果 CUDA crash 的平均间隔短于一个完整 epoch，可能出现：



```Plain Text
Epoch 15
→ 跑到 590
→ 崩溃

Epoch 15
→ 从 0 重来
→ 跑到 1469
→ 崩溃

Epoch 15
→ 又从 0 重来
```



这样即使自动重启有效，也可能长期无法跨过当前 epoch。



因此进一步设计：



\> **在一个 epoch 内定期保存 recovery checkpoint。**



**\-\-\-**



### **Recovery checkpoint 设计**



在原有正式 checkpoint callback 之外，新增独立：



```Plain Text
recovery/
```



目录。



目标是每隔一定训练 step 更新：



```Plain Text
recovery/last.ckpt
```



初始设计频率：



```Plain Text
every_n_train_steps = 100
```



这样即使在一个 epoch 中途崩溃，也可以优先从较新的 recovery checkpoint 恢复，而不是永远退回前一个完整 epoch。



**\-\-\-**



### **Resume 逻辑改为比较两个 last\.ckpt**



恢复逻辑从只检查：



```Plain Text
main last.ckpt
```



改成同时检查：



```Plain Text
checkpoints/.../last.ckpt

checkpoints/.../recovery/last.ckpt
```



然后：



```Python
ckpt_path = max(
    resume_candidates,
    key=os.path.getmtime,
)
```



即：



\> **谁的修改时间更新，就从谁恢复。**



**\-\-\-**



### **当前 recovery checkpoint 代码状态**



截至本记录更新时，`train.py` 已经加入：



- recovery checkpoint callback；

- `recovery/last.ckpt` 路径；

- main/recovery checkpoint 时间比较；

- `trainer.fit(..., ckpt_path=ckpt_path)` 恢复逻辑。

但最新一次代码审查发现，上传版本中 recovery callback 仍写为：



```Python
monitor=None
save_top_k=1
save_last=True
every_n_train_steps=100
```



这里建议继续修正为：



```Python
monitor=None
save_top_k=0
save_last=True
every_n_train_steps=100
```



并可删除 recovery `filename=...`，只维护最新的：



```Plain Text
recovery/last.ckpt
```



原因是 recovery 的目标不是保存一系列 best checkpoint，而只是保留一个最近的“救命存档”。



**\*\*因此截至当前，mid\-epoch recovery 机制属于“代码已加入、最后配置修正与实际崩溃恢复效果仍需验证”的状态，不能像 epoch\-level \`last\.ckpt\` 那样视为已经完全验收。\*\***



另外，由于训练数据使用 streaming `IterableDataset`，即使中途恢复了模型、optimizer、scheduler、global step 等状态，也不应承诺能够逐样本精确回到完全相同的数据流位置；当前设计的核心目标是减少整轮 epoch 被重复计算的损失。



**\-\-\-**



## **截至 2026\-08\-17 的实际实验状态**



当前整体状态可以概括为：



```Plain Text
Tahoe-100M 本地数据                ✅
数据完整性检查                     ✅
损坏 parquet 修复                   ✅
固定 25% training subset           ✅
固定 validation shards              ✅

D=12 / heads=6                      ✅
随机初始化                          ✅

2 × RTX A6000                       ✅
Lightning DDP                       ✅
NCCL CUMEM workaround               ✅
双卡无 P2P / NVLink                 已确认

Per-GPU batch size = 92             ✅
Gradient accumulation = 2           ✅
Effective batch size = 368          ✅
BF16 mixed precision                ✅

Training DataLoader workers=2/rank  ✅
DDP train shard split 422/421       ✅
Validation shard split 8/8          ✅

TensorBoard                         ✅
val_loss 实时曲线                    ✅
W&B offline                         ✅

原训练预算 1M × 50                  已取消
当前训练预算 700k × 30              ✅
总 optimizer updates = 57090        ✅

Epoch-level checkpoint resume       ✅ 已实际验证
自动 crash/restart/resume           ✅ 已实际验证

Recurring rank1 CUDA failure         ⚠️ 仍存在
Epoch 15 反复重跑                   ⚠️ 已发生
Mid-epoch recovery checkpoint        🟡 已加入代码，待最终修正/验证

正式训练最终完成                     ⏳ 尚未完成
```



当前最主要的工程风险已经不是数据、DataLoader 或模型能否启动，而是：



\> **长期双卡训练中的 rank1 CUDA 稳定性，以及如何在这种不稳定条件下尽可能减少失败重算并完成剩余训练。**



**\-\-\-**



## **当前的标准配置描述**



```Plain Text
当前 GeneJEPA 使用 PyTorch Lightning + 双卡 DDP，
2×RTX A6000，BF16 mixed precision。

模型：
D=12，heads=6，d=768，L=512。

数据：
固定 Tahoe training pool 的 25%，843/3372 shards；
DDP 下 rank0/rank1 分别使用 422/421 个 training shards。

Batch：
92 per GPU；
双卡 global raw batch=184；
gradient accumulation=2；
effective batch size=368。

训练预算：
train_samples=700,000 / epoch；
3805 raw batches / epoch；
1903 optimizer updates / epoch；
max_epochs=30；
57090 total optimizer updates。

DataLoader：
training num_workers=2 per rank；
validation workers=0。

监控：
W&B offline + TensorBoard；
每个 epoch 记录 val_loss；
best checkpoint 监控 val_loss。

当前主要问题：
长期双卡训练 rank1 偶发 CUDA failure；
epoch-level auto resume 已可工作；
正在增加 mid-epoch recovery checkpoint，
以避免同一个 epoch 反复从头重跑。
```



**\-\-\-**



## **更新后的一句话总结**



本次 GeneJEPA 复现已经从最初的“能否把 25% Tahoe、D=12、heads=6 的模型跑起来”，进一步进入了真正的长训练工程阶段：



```Plain Text
固定 25% Tahoe 数据池
→ 训练预算从 1M×50 压缩到 700k×30
→ 明确 batch / raw batch / optimizer / epoch 的关系
→ 确认 gradient accumulation=2
→ 确认 BF16 mixed precision
→ 接入 TensorBoard 实时观察 val_loss
→ 正式双卡 DDP 长训练
→ checkpoint resume
→ CUDA crash 自动重启
→ 为 Epoch 15 反复重跑增加 mid-epoch recovery 机制
```



当前模型的 validation loss 已显示出持续下降趋势，但正式 30\-epoch 任务尚未最终完成。



下一阶段的直接目标不是再改变模型或数据定义，而是：



\> **在保持当前实验配置一致的前提下，利用 checkpoint / auto\-resume / recovery checkpoint 尽可能稳定完成剩余训练，并最终整理完整 validation loss curve、best checkpoint 和最终实验结果。**



**\-\-\-**



## **技术顾问提出事项与当前实际情况对照**

|技术顾问关注点|顾问意图|当前实际情况|状态|
|---|---|---|---|
|BF / BF16|确认是否使用低精度训练加速<br>|当前日志明确为 `bf16-mixed`，RTX A6000 支持 BF16|✅ 已使用|
|Batch size|确认训练批次规模<br>|`92 per GPU`；双卡 raw batch=184；grad accumulation=2；effective batch=368|✅ 已明确|
|Gradient accumulation|减少频繁更新/通信，并模拟更大的 effective batch<br>|Lightning 已设置 `accumulate_grad_batches=2`，不需要额外手写几行实现|✅ 已使用|
|Gradient accumulation benchmark|判断不同累积值是否还能进一步提速|没有专门比较 `1/2/4` 的速度；只验证当前 `2` 可正常训练|⏸ 未单独 benchmark|
|DeepSpeed<br>|尝试优化多 GPU / 通信 / 显存|当前仍是 Lightning DDP；尚未实际切换或 benchmark DeepSpeed|⏸ 未实施<br>|
|Hugging Face Accelerate|尝试其他分布式训练管理方案|当前 Lightning 已承担训练管理；没有为了 Accelerate 重写工程|⏸ 未实施|
|减少训练时间|原 50 epochs 预计约两周，需压缩|没有直接把 dataset 改成 10%；而是将 `1M×50` 改为 `700k×30`，主要计算预算约剩原来的 42%|✅ 已调整|
|Dataset 25% → 10%|最初作为缩短训练时间的方案|分析后确认 subset 比例主要控制数据池多样性，不直接控制当前 `limit_train_batches`；最终继续固定 25%|✅ 决定保持 25%|
|Epoch 数量|顾问认为 50 可能没有必要|已将 `max_epochs` 从 50 降到 30|✅ 已调整|
|每 epoch sample budget|直接减少每轮计算量|`train_samples` 从 1,000,000 降到 700,000|✅ 已调整|
|TensorBoard|边训练边观察 validation/test loss curve|已接入 TensorBoard 2\.20\.0，并通过 smoke test 验证 `val_loss` 可实时显示且呈下降趋势|✅ 已完成|
|Validation loss curve|用实际收敛情况判断是否还需要继续训练|当前每 epoch 做 validation，核心指标统一为 `val_loss`，checkpoint 也监控 `val_loss`|✅ 已有|
|Test loss curve|顾问口头提及 validate 或 test|当前工程确认的是 validation pipeline；没有新增独立 test pipeline/test loss|⏸ 当前以 validation 为主|
|训练框架|确认当前工程如何管理训练|当前为 `PyTorch + PyTorch Lightning + DDP`|✅ 已明确|
|DataLoader 性能|避免 GPU 等数据|已 benchmark 0/2/4/8 workers，最终使用 `GENEJEPA_TRAIN_WORKERS=2`（每 rank 2 workers）|✅ 已完成|
|长任务断点恢复|避免 CUDA crash 后全部重跑|epoch\-level `last.ckpt` resume 已多次验证；额外增加 `auto_resume_genejepa.sh`|✅ 已完成基础恢复|
|中途 checkpoint|避免 Epoch 15 每次从头重跑|已设计每 100 train steps 的 recovery checkpoint，并加入“main/recovery 取较新者”逻辑；最后配置仍待修正和实测|🟡 进行中|
|CUDA 稳定性|非顾问最初要求，但已成为当前主要风险<br>|rank1 多次出现 `CUDA unknown error / unspecified launch failure`；自动恢复可绕过部分影响，但根因尚未解决|⚠️ 未解决|





## 训练结果

### vocabulary

[genejepa\_gene\_vocabulary\.csv](图片和附件/genejepa_gene_vocabulary.csv)

### Loss curve

![genejepa\_train\_sim\_loss\_curve\.png](图片和附件/genejepa_train_sim_loss_curve.png)



![genejepa\_val\_loss\_curve\.png](图片和附件/genejepa_val_loss_curve.png)



## Benchmark

### 开始设计外挂 Benchmark

根据技术顾问建议，训练结束后不能只依赖 GeneJEPA 自己的 `val_loss` 判断模型效果。

`val_loss` 只能反映：

> Student / Predictor 对 Teacher representation 的预测目标完成得怎么样。
> 
> 

但它不能直接回答：

> GeneJEPA 最后生成的 cell embedding 是否真的包含有意义的生物学信息。
> 
> 

因此决定增加一个**训练之外的 external benchmark**。

Benchmark 不参与 GeneJEPA 参数更新，而是在训练结束后异步执行：

```Plain Text
已经训练好的 GeneJEPA checkpoint
        ↓
冻结模型参数
        ↓
外部单细胞表达数据
        ↓
GeneJEPA EMA Teacher
        ↓
生成每个 cell 的 768-d embedding
        ↓
简单下游分类器
        ↓
预测 cell type
        ↓
评价 embedding quality
```

Benchmark 的核心目的不是训练一个很强的 cell\-type classifier，而是检测：

> **GeneJEPA 自己生成的 embedding 中，是否已经存在可以被简单模型直接读取的 cell\-type information。**
> 
> 

---

### 为什么没有直接沿用作者的 supervised probe

GeneJEPA 原训练代码中其实已经配置：

```Python
SupervisedValidatorCallback(
    probe_dataset_path=
        "scvi-tools/human-lung-cell-atlas-scanvi",
    probe_cell_type_col="scanvi_label",
    max_probe_cells=10_000,
)
```

说明作者本身也使用 HLCA 做 supervised representation evaluation。

但作者的 probe 并不是我们希望使用的最严格线性 readout。

我们的顾虑是：

```Plain Text
GeneJEPA embedding
        ↓
能力较强的 MLP classifier
        ↓
很高的分类结果
```

此时很难完全区分：

```Plain Text
A. GeneJEPA embedding 本身已经组织得很好

还是

B. embedding 中的信息仍然比较纠缠，
   但后面的 MLP 自己又学到了复杂的非线性分类规则
```

因此本次 benchmark 决定采用能力更弱的：

```Plain Text
Multiclass Logistic Regression
```

即严格的 linear probe：

```Plain Text
768-d embedding
        ↓
线性分类边界
        ↓
18 cell types
```

没有：

```Plain Text
hidden layer
GELU
Transformer
attention
额外非线性网络
```

所以如果 Logistic Regression 仍然可以区分 cell type，更能说明：

> **cell\-type 信息已经被 GeneJEPA embedding 本身编码，并具有一定线性可读性。**
> 
> 

---

### Benchmark 的主要研究问题

本次 benchmark 主要回答两个问题。

#### 问题一：GeneJEPA embedding 有没有 cell\-type information？

即：

```Plain Text
HLCA expression
↓
GeneJEPA embedding
↓
简单 Logistic Regression
↓
能否预测真实 cell type
```

如果分类能力明显高于无信息状态，说明 embedding 中确实存在生物学结构。

#### 问题二：JEPA `val_loss` 是否对应 downstream representation quality？

因此不能只评估一个 checkpoint，而是选择多个 checkpoint：

```Plain Text
Epoch24
Epoch25
Epoch29
```

全部使用：

```Plain Text
完全相同的 HLCA cells
完全相同的 gene mapping
完全相同的 train/test split
完全相同的 embedding extraction
完全相同的 Logistic Regression
```

唯一变化：

```Plain Text
GeneJEPA checkpoint
```

最终比较：

```Plain Text
JEPA val_loss
vs
HLCA downstream Accuracy / Macro-F1 / Balanced Accuracy
```

---

### 检查可用于 Benchmark 的 checkpoint

实际 checkpoint 检查结果：

```Plain Text
Epoch19 recovery
global_step = 37500

Epoch22 recovery
global_step = 43300

Epoch24
global_step = 47575
val_loss ≈ 0.18629

Epoch25
global_step = 49478
val_loss ≈ 0.17945

Epoch29 / last.ckpt
global_step = 57090
val_loss ≈ 0.20441
```

其中：

```Plain Text
Epoch25
```

是完整训练过程中目前 `val_loss` 最好的 checkpoint。

第一阶段正式 benchmark 最终选择：

```Plain Text
Epoch24
Epoch25
Epoch29
```

作为 late\-stage checkpoint 对比。

Epoch19 / Epoch22 暂时保留，后续如果需要增加更多时间点，可以再补 benchmark。

---

### 第一次尝试 HLCA：发现 minified AnnData 问题

最初按照 GeneJEPA 作者代码中的：

```Plain Text
scvi-tools/human-lung-cell-atlas-scanvi
```

下载了约：

```Plain Text
760 MB
```

的：

```Plain Text
adata.h5ad
```

检查结果：

```Plain Text
584,944 cells
2,000 genes
scanvi_label 存在
```

但是：

```Plain Text
adata.X
```

虽然 shape 正常，却发现：

```Plain Text
nnz = 0
```

也就是整个表达矩阵为空。

进一步加载对应 SCANVI model 后确认：

```Plain Text
Model's adata is minified?: True
```

SCANVI 本身能够根据保存的模型状态重新生成 normalized expression。

但是这里存在一个 benchmark 独立性问题：

```Plain Text
SCANVI 本身使用 cell-type supervision
        ↓
用 SCANVI 恢复 expression
        ↓
再使用这些数据测试 cell-type classification
```

可能把 SCANVI 本身学到的信息带入 benchmark。

因此最终决定：

> **放弃使用 minified SCANVI AnnData 生成表达矩阵。**
> 
> 

重新寻找真正包含原始表达数据的 HLCA Core。

---

### 下载并检查完整 HLCA Core

最终下载：

```Plain Text
benchmark_data/hlca/
688185ad-11c2-4172-a53a-f4f1f4076860.h5ad
```

文件大小约：

```Plain Text
5.47 GB
```

数据规模：

```Plain Text
584,944 cells
27,402 genes
```

HLCA 提供多个 annotation hierarchy：

```Plain Text
ann_level_1       4 classes
ann_level_2      11 classes
ann_level_3      25 classes
cell_type        50 classes
ann_finest_level 61 classes
```

其中：

```Plain Text
ann_level_1:
Epithelial
Immune
Endothelial
Stroma
```

本次第一版正式 benchmark 最终选择：

```Plain Text
ann_level_3
```

作为分类标签。

---

### 确认 HLCA 中真正使用哪一个 expression matrix

完整 HLCA 同时包含：

```Plain Text
adata.X
adata.raw.X
```

检查发现：

### `adata.X`

前100个 cell 的非零值：

```Plain Text
min ≈ 0.0687
max ≈ 9.98
```

属于已经 normalized / transformed 的表达。

### `adata.raw.X`

前100个 cell：

```Plain Text
min nonzero = 1
max = 5963
```

属于 count\-like expression。

由于 GeneJEPA 自己的输入 pipeline 会执行：

```Plain Text
raw expression
↓
log1p
↓
Tahoe global mean/std normalization
```

因此正式 benchmark 决定使用：

```Plain Text
adata.raw.X
```

避免把已经 normalized 的 `adata.X` 再次执行 GeneJEPA preprocessing。

---

### HLCA → GeneJEPA gene vocabulary 检查

GeneJEPA 当前 Tahoe vocabulary：

```Plain Text
62,710 genes
```

HLCA：

```Plain Text
27,402 genes
```

第一轮仅使用：

```Plain Text
gene symbol
```

进行 mapping 时得到：

```Plain Text
Mapped   = 27,098
Unmapped = 304
Overlap  = 98.89%
```

之后进一步检查：

```Plain Text
Ensembl ID
+
gene symbol
```

发现：

```Plain Text
Both match, same index : 27080
Ensembl only           :   304
Symbol fallback        :     1
Mapping conflicts      :    17
Completely unmapped    :     0
```

最终正式 mapping rule 固定为：

```Plain Text
1. 优先使用 Ensembl ID
2. Ensembl 无法映射时才使用 gene symbol fallback
3. Ensembl 与 symbol 指向不同 GeneJEPA index 时，以 Ensembl 为准
```

最终：

```Plain Text
Final mapped genes = 27,402 / 27,402
Final overlap      = 100.00%
```

即：

> **HLCA 全部27,402个基因都可以映射到 GeneJEPA/Tahoe vocabulary。**
> 
> 

---

### HLCA → GeneJEPA embedding 20\-cell smoke test

在正式跑几十万 cells 前，先随机选择20个 HLCA cells 做端到端 smoke test：

```Plain Text
HLCA raw counts
↓
gene mapping
↓
log1p
↓
Tahoe global normalization
↓
Epoch25 EMA Teacher
↓
768-d embedding
```

结果：

```Plain Text
Embedding shape = (20, 768)
Finite          = True
```

embedding norm：

```Plain Text
mean ≈ 39.54
std  ≈ 0.19
```

20个 cell 的 pairwise cosine similarity：

```Plain Text
mean ≈ 0.952
min  ≈ 0.852
max  ≈ 0.9999
```

证明：

- HLCA raw counts 可以成功输入 GeneJEPA；

- gene mapping 正常；

- normalization 正常；

- checkpoint 能加载；

- EMA Teacher inference 正常；

- embedding 全部 finite。

---

### 第一版 10k benchmark cohort 尝试失败

最初参考作者：

```Plain Text
max_probe_cells = 10,000
```

准备从 HLCA 中抽取：

```Plain Text
10,000 cells
```

并使用：

```Plain Text
80% train
20% test
stratified split
seed = 42
```

但 `ann_level_3` 中存在大量极小类别，例如：

```Plain Text
Lymphatic EC proliferating      28
Smooth muscle FAM83D+          335
SM activated stress response   556
Lymphatic EC differentiating   566
Myofibroblasts                 716
Rare                           885
```

先抽10k后，某些类别甚至只剩：

```Plain Text
1 cell
```

导致第二次 stratified train/test split 报错：

```Plain Text
ValueError:
The least populated class in y has only 1 member
```

说明：

> 直接保留所有稀有类别再抽10k，不适合做稳定的 multiclass benchmark。
> 
> 

---

### 正式 Benchmark cohort 改为 18 类 \+ 全部细胞

最终决定：

```Plain Text
使用 ann_level_3
↓
删除无有效标签的 None
↓
删除全数据中 <1000 cells 的类别
↓
剩余类别全部纳入
```

去除的6类：

```Plain Text
Lymphatic EC proliferating       28
Smooth muscle FAM83D+           335
SM activated stress response    556
Lymphatic EC differentiating    566
Myofibroblasts                  716
Rare                            885
```

最终：

```Plain Text
18 classes
578,572 cells
```

18类：

```Plain Text
Macrophages                111844
Basal                       84713
Secretory                   80327
AT2                         62405
T cell lineage              50859
Multiciliated lineage       41098
Monocytes                   26529
EC capillary                23205
Fibroblasts                 20384
Innate lymphoid cell NK     16978
EC venous                   12975
Dendritic cells             10319
AT1                          7937
EC arterial                  7391
Mast cells                   6623
B cell lineage               6284
Submucosal Secretory         4700
Lymphatic EC mature          4001
```

---

### 固定 Train/Test split

全部578,572个 benchmark cells 按：

```Plain Text
80% train
20% test
stratified
seed = 42
```

固定划分。

最终：

```Plain Text
Total = 578,572

Train = 462,857
Test  = 115,715

Classes = 18
```

最小 test class：

```Plain Text
Lymphatic EC mature
800 cells
```

最大 test class：

```Plain Text
Macrophages
22,369 cells
```

固定 cohort 保存为：

```Plain Text
benchmark_data/hlca/
benchmark_ann_level3_all18_seed42.csv
```

该文件从此冻结。

后续：

```Plain Text
Epoch24
Epoch25
Epoch29
```

全部使用完全相同的：

```Plain Text
cell_index
label
train/test split
```

不得重新随机划分。

---

### 为什么最终没有限制在作者的 10k cells

作者的 `10,000 cells` 主要存在于训练过程中的 supervised callback。

我们的 benchmark 是：

```Plain Text
训练已经结束
↓
离线独立运行
```

因此计算成本并不是主要限制。

使用全部符合 benchmark 定义的细胞有几个优点：

```Plain Text
1. 减少随机抽样波动
2. 小类别 test 样本更多
3. Macro-F1 更稳定
4. checkpoint 之间比较更加 solid
```

因此最终没有继续人为下采样到10k，而是使用：

```Plain Text
578,572 cells
```

需要注意：

> 当前 split 是 cell\-level stratified split，而不是 donor\-disjoint split。
> 
> 

所以当前 benchmark 最适合回答：

> **不同 GeneJEPA checkpoint 的 representation quality 谁更好。**
> 
> 

它暂时不能被解释成严格的：

> 对完全未见过 donor 的泛化能力。
> 
> 

如果后续需要更严格 external generalization benchmark，可以再增加 donor\-disjoint split。

---

### 建立批量 embedding extraction 脚本

正式建立：

```Plain Text
extract_hlca_embeddings.py
```

核心流程：

```Plain Text
Frozen benchmark CSV
↓
按 HLCA cell_index 排序
↓
backed H5AD 分 batch 读取 raw.X
↓
HLCA gene index → GeneJEPA index
↓
log1p
↓
Tahoe global mean/std
↓
EMA Teacher get_embedding()
↓
768-d embedding
↓
直接写 disk-backed .npy
```

Tahoe normalization 使用训练阶段同一组固定统计：

```Plain Text
mean = 0.8255348793661643
std  = 0.31346807453602465
```

Inference 固定：

```Python
use_teacher=True
```

即正式 benchmark 使用：

> **EMA Teacher encoder 的 embedding。**
> 
> 

embedding 输出使用：

```Plain Text
float32
```

---

### 1000\-cell batch extraction smoke test

正式大规模提取前先跑：

```Plain Text
1000 cells
batch_size = 64
Epoch25
GPU0
```

结果：

```Plain Text
Shape = (1000, 768)
Finite = True
Mapped genes = 27402 / 27402

Mean throughput ≈ 66.31 cells/s
```

说明批量 extraction pipeline 可以正常工作。

---

### embedding extraction 改为双 GPU 独立分片

考虑到之前训练阶段 DDP / NCCL 存在不稳定问题，本次 inference 没有使用 DDP。

而是采用：

```Plain Text
578,572 cells
        ↓
排序
        ↓
切成两个连续 shard
      ↙           ↘
 GPU0             GPU1
独立进程         独立进程
      ↘           ↙
      最后磁盘合并
```

两张 GPU 完全独立：

```Plain Text
不使用 DDP
不使用 NCCL
不进行 GPU 间通信
```

这样既可以双卡加速，又不会重新引入训练阶段 NCCL instability。

---

### 双 GPU extraction smoke test

先测试：

```Plain Text
总共 2000 cells
```

两张 GPU：

```Plain Text
GPU0 → 1000 cells
GPU1 → 1000 cells
```

结果：

```Plain Text
GPU0 ≈ 51.19 cells/s
GPU1 ≈ 82.92 cells/s
```

两个进程都成功输出：

```Plain Text
(1000, 768)
```

虽然两边速度存在差异，但整体 wall\-clock throughput 明显优于单卡，因此正式采用双进程双 GPU 方案。

---

### Epoch25 全量 embedding extraction

Epoch25 checkpoint：

```Plain Text
scjepa-epoch=25-val_loss=0.179.ckpt
```

使用：

```Plain Text
batch_size = 64
num_shards = 2
```

两个 shard：

```Plain Text
part0 = 289,286 cells
part1 = 289,286 cells
```

最终两边都完成：

```Plain Text
Shape = (289286, 768)
```

然后使用：

```Plain Text
merge_hlca_embeddings.py
```

合并。

完整性检查：

```Plain Text
Combined rows: 578572

Frozen benchmark match: OK
Finite check: OK

Classes: 18

Train = 462857
Test  = 115715
```

最终：

```Plain Text
epoch25_all18_embeddings.npy
shape = (578572, 768)

epoch25_all18_rows.csv

Embedding size ≈ 1.66 GB
```

---

### Epoch24 / Epoch29 embedding extraction

随后对：

```Plain Text
Epoch24
Epoch29
```

执行完全相同的 embedding extraction。

#### Epoch24

```Plain Text
part0 = 289286 × 768
part1 = 289286 × 768
```

第一次 Epoch24 `part1` 在 GPU1 中途出现：

```Plain Text
RuntimeError:
CUDA error: unspecified launch failure
```

由于 `.npy` 使用 memmap 创建，即使进程中途崩溃，文件表面上仍可能具有完整文件大小。

因此不能通过：

```Plain Text
文件存在
或
文件大小正常
```

判断 extraction 是否完成。

处理方式：

```Plain Text
删除失败的 Epoch24 part1
↓
保留成功 part0
↓
改用 GPU0 单独重新跑 part1
```

补跑成功：

```Plain Text
[4521/4521]
cells = 289286 / 289286

Shape = (289286, 768)

Mean throughput ≈ 60.96 cells/s
```

#### Epoch29

Epoch29 两个 shard 均正常完成。

---

### Epoch24 / Epoch29 merge 和完整性检查

分别建立：

```Plain Text
merge_hlca_embeddings_epoch24.py
merge_hlca_embeddings_epoch29.py
```

两个 checkpoint 均得到：

```Plain Text
Embedding shape = (578572, 768)

Rows = 578572
Classes = 18

Train = 462857
Test  = 115715

Embedding size ≈ 1.66 GB
```

并全部通过：

```Plain Text
Frozen benchmark match: OK
Finite check: OK
```

最终正式 embedding：

```Plain Text
benchmark_results/hlca18/
├── epoch24_all18_embeddings.npy
├── epoch24_all18_rows.csv
│
├── epoch25_all18_embeddings.npy
├── epoch25_all18_rows.csv
│
├── epoch29_all18_embeddings.npy
└── epoch29_all18_rows.csv
```

所以三个 checkpoint 在进入分类器以前已经确认：

```Plain Text
完全相同的578,572个细胞
完全相同的行顺序
完全相同的 label
完全相同的 train/test split
全部 finite
```

---

### 正式 Linear Probe 设计

下游 probe 固定为：

```Plain Text
StandardScaler
↓
Multiclass Logistic Regression
```

StandardScaler：

```Plain Text
只在 training set 上 fit
再 transform train/test
```

避免使用 test set 信息进行预处理。

Logistic Regression 最终固定：

```Python
LogisticRegression(
    penalty="l2",
    C=1.0,
    solver="lbfgs",
    max_iter=5000,
    tol=1e-4,
    random_state=42,
)
```

并固定：

```Plain Text
class_weight = None
```

没有使用：

```Plain Text
class_weight="balanced"
```

也没有针对 test result 调节：

```Plain Text
C
penalty
classifier architecture
```

原因是：

> Benchmark 的目标不是把 Logistic Regression 调到最高分类性能，而是用固定且简单的 probe 比较 GeneJEPA embedding。
> 
> 

---

### Benchmark 指标的含义

正式关注：

```Plain Text
Accuracy
Macro-F1
Balanced Accuracy
```

另外 classification report 中还有：

```Plain Text
Precision
Recall
F1
Support
```

#### Accuracy

表示：

> **所有 test cells 混在一起，有多少比例预测正确。**
> 
> 

例如：

```Plain Text
Accuracy = 0.59
```

表示约：

```Plain Text
59%
```

的所有 test cells 分类正确。

#### Recall

针对某一个 cell type：

> **真正属于这一类的细胞中，有多少被成功识别出来。**
> 
> 

例如：

```Plain Text
Macrophages Recall = 0.8167
```

表示：

```Plain Text
真实 Macrophages 中约81.67%
被成功识别为 Macrophages
```

#### Precision

表示：

> **被模型预测成某一类的细胞中，有多少真的属于这一类。**
> 
> 

#### F1

F1 同时考虑：

```Plain Text
Precision
+
Recall
```

只有：

```Plain Text
预测得准
并且
找得比较全
```

F1 才会高。

#### Macro\-F1

先分别计算18个类别各自的 F1，然后：

```Plain Text
18个 F1 直接平均
```

每个类别权重完全相同。

所以：

```Plain Text
800个细胞的小类
```

和：

```Plain Text
22000多个细胞的大类
```

在 Macro\-F1 里都只算“一票”。

因此 Macro\-F1 对类别不平衡更敏感。

#### Balanced Accuracy

相当于：

```Plain Text
18个类别 Recall 的平均
```

每个类别同等重要。

---

### Logistic Regression convergence smoke test

正式跑46万 training cells 前，先使用：

```Plain Text
20,000 train
5,000 test
```

做 solver / convergence smoke test。

#### max\_iter = 300

结果：

```Plain Text
ConvergenceWarning
Iterations = 300

Accuracy          = 0.452800
Macro-F1          = 0.249647
Balanced Accuracy = 0.247595
```

说明：

> 300 iterations 不足以完成 LBFGS optimization。
> 
> 

#### max\_iter = 1000

结果：

```Plain Text
ConvergenceWarning
Iterations = 1000

Accuracy          = 0.508600
Macro-F1          = 0.313506
Balanced Accuracy = 0.304565
```

仍然撞到 iteration 上限。

#### max\_iter = 5000

最终实际：

```Plain Text
Iterations = 1796
```

LBFGS 在第1796次自行满足 convergence condition，没有跑满5000。

结果：

```Plain Text
Accuracy          = 0.512200
Macro-F1          = 0.315321
Balanced Accuracy = 0.306654
```

这说明：

```Plain Text
max_iter = 5000
```

只是一个允许优化器充分求解的上限，并不意味着一定执行5000次。

因此从此正式冻结：

```Plain Text
solver = lbfgs
max_iter = 5000
tol = 1e-4
```

---

### Epoch25 正式全量 Linear Probe

正式使用：

```Plain Text
Train X = (462857, 768)
Test X  = (115715, 768)

18 classes
```

结果：

```Plain Text
Accuracy          = 0.592914
Macro-F1          = 0.432404
Balanced Accuracy = 0.406109

Iterations        = 4951
```

LBFGS 在5000上限之前正常收敛。

训练时间约：

```Plain Text
76.85 min
```

---

### Epoch25 各 cell type 的分类结果

正式 test set：

表现相对较好的类别包括：

```Plain Text
Macrophages
Multiciliated lineage
EC capillary
T cell lineage
AT2
Basal
Secretory
```

比较弱的类别包括：

```Plain Text
Dendritic cells
EC arterial
B cell lineage
Lymphatic EC mature
EC venous
Mast cells
```

---

### Epoch24 / Epoch25 / Epoch29 正式 checkpoint 对比

三者全部使用：

```Plain Text
同一个578,572-cell benchmark
同一个 train/test split
同一个 StandardScaler
同一个 Logistic Regression
```

正式结果：

三个指标的排序完全一致：

```Plain Text
Epoch25 > Epoch24 > Epoch29
```

而 JEPA validation loss 的排序为：

```Plain Text
Epoch25 < Epoch24 < Epoch29
```

即至少在这三个 late\-stage checkpoint 上：

> **JEPA ****`val_loss`**** 最好的 Epoch25，同时也是 downstream linear probe 表现最好的 checkpoint。**
> 
> 

但目前只比较了3个 checkpoint，因此更严谨的表述应该是：

> 在 Epoch24、25、29 三个时间点观察到一致的 ranking。
> 
> 

暂时不能据此声称所有训练阶段中：

```Plain Text
val_loss
```

与 downstream representation quality 一定高度相关。

---

### Epoch25 confusion matrix 分析

为了进一步理解：

```Plain Text
Accuracy ≈ 59.3%
Macro-F1 ≈ 43.2%
```

到底错在哪里，重新运行一次 Epoch25 Logistic Regression，并永久保存逐细胞 prediction。

新脚本：

```Plain Text
run_hlca_linear_probe_epoch25_confusion.py
```

输出：

```Plain Text
benchmark_results/hlca18/
├── epoch25_predictions_full.csv
├── epoch25_confusion_matrix_raw_full.csv
├── epoch25_confusion_matrix_row_normalized_full.csv
├── epoch25_top3_misclassifications_full.csv
└── epoch25_confusion_matrix_row_normalized_full.png
```

重新运行完全复现原结果：

```Plain Text
Accuracy          = 0.592914
Macro-F1          = 0.432404
Balanced Accuracy = 0.406109

Iterations = 4951
```

说明 confusion\-matrix 版本没有改变 benchmark protocol。

---

### confusion matrix 应该怎样理解

当前保存的是：

```Plain Text
row-normalized confusion matrix
```

纵轴：

```Plain Text
True cell type
```

横轴：

```Plain Text
Predicted cell type
```

所以：

> 每一行代表一种真实 cell type。
> 
> 

每一行总和：

```Plain Text
100%
```

### 对角线

表示：

```Plain Text
真实类别
=
预测类别
```

即预测正确。

每个类别对角线的比例实际上就是该类别的：

```Plain Text
Recall
```

所以：

```Plain Text
对角线越亮
→ 这一类 Recall 越高
→ 越容易被正确识别
```

对角线以外的格子则表示：

> 这个真实 cell type 被错分到了什么类型。
> 
> 

---

### Epoch25 主要 misclassification 现象

#### Macrophages

```Plain Text
Recall = 81.67%
F1     = 71.99%
```

是真实识别效果最好的主要类别之一。

---

#### Dendritic cells

```Plain Text
Recall = 5.09%
F1     = 9.04%
```

主要错误：

```Plain Text
Dendritic
→ Macrophages     50.29%
→ Monocytes        9.79%
→ T cell lineage   9.74%
```

说明：

> Dendritic cells 大量被吸收到其他 immune / myeloid 类别中。
> 
> 

---

#### B cell lineage

```Plain Text
Recall = 9.55%
F1     = 15.64%
```

主要错误：

```Plain Text
B cell lineage
→ T cell lineage 45.58%
→ Macrophages    12.89%
→ Basal           9.39%
```

说明 B / T 等 lymphoid subtype 的线性区分仍然较弱。

---

#### Monocytes

```Plain Text
Recall = 26.91%
F1     = 34.49%
```

主要：

```Plain Text
Monocytes
→ Macrophages 47.70%
```

Monocyte / Macrophage 是当前非常明显的一组混淆。

---

#### Innate lymphoid cell NK

```Plain Text
Recall = 36.93%
F1     = 43.76%
```

最大的错误：

```Plain Text
NK
→ T cell lineage ≈ 36.96%
```

说明 NK 与 T lineage 在 embedding 空间中距离较近。

---

#### EC arterial

```Plain Text
Recall = 7.85%
F1     = 12.87%
```

主要：

```Plain Text
EC arterial
→ EC capillary 28.42%
→ Macrophages  10.83%
→ EC venous    10.49%
```

一部分错误属于 endothelial subtype 内部混淆，但同时存在明显跨谱系预测。

---

#### EC venous

```Plain Text
Recall = 21.04%
F1     = 27.53%
```

主要：

```Plain Text
EC venous
→ Macrophages  13.41%
→ T cell       12.49%
→ EC capillary 12.41%
```

---

#### Lymphatic EC mature

```Plain Text
Recall = 9.00%
F1     = 15.30%
```

错误分布比较分散：

```Plain Text
→ Macrophages
→ EC venous
→ T cell lineage
→ Basal
→ EC capillary
→ AT2
```

因此这类比单纯的相近 subtype confusion 更值得后续关注。

---

### 当前对 Benchmark 结果的理解

不能把：

```Plain Text
Accuracy = 59.29%
```

简单理解成：

> GeneJEPA 只能识别59%的细胞，所以模型很差。
> 
> 

本次 probe 是：

```Plain Text
18-class
严格线性 Logistic Regression
```

而不是强大的 nonlinear classifier。

因此当前更准确的结论是：

> **Epoch25 GeneJEPA embedding 中确实存在明显的 cell\-type information，而且相当一部分信息已经能够被简单线性模型读取。**
> 
> 

但是：

> **这种线性可分性在18个 cell type 之间非常不均匀。**
> 
> 

部分大类和主要 cell type：

```Plain Text
Macrophages
T cell lineage
Multiciliated lineage
EC capillary
AT2
Basal
Secretory
```

已经表现出较明显的线性结构。

而：

```Plain Text
Dendritic cells
B cell lineage
EC arterial
EC venous
Lymphatic EC mature
```

仍然比较困难。

---

### 类别数量不平衡可能是一个重要影响因素

当前18类数量差异很大。

test support：

```Plain Text
Lymphatic EC mature       800
Submucosal Secretory      940
B cell lineage           1257
...
Macrophages             22369
```

总体趋势上：

> 大类别通常比小类别更容易获得较高 Recall / F1。
> 
> 

但不能把所有低 F1 都解释为“细胞太少”。

例如：

```Plain Text
Submucosal Secretory
support = 940
F1      = 0.474
```

而：

```Plain Text
Dendritic cells
support = 2064
F1      = 0.090
```

Dendritic 的 test cells 数量更多，但结果反而明显更差。

说明最终表现同时受到：

```Plain Text
类别数量
+
类别本身与其他 cell type 的相似度
+
GeneJEPA representation quality
+
Tahoe → normal lung 的 domain shift
+
当前 Logistic Regression class imbalance
```

等多个因素影响。

本次主 benchmark 明确固定：

```Plain Text
class_weight = None
```

因此不会为了提升小类别结果而在 Epoch25 后单独改变 classifier。

否则会破坏 Epoch24 / 25 / 29 的公平比较。

---

### 对 Tahoe 25% pretraining subset 的新疑问

当前出现一个值得后续检查的问题：

GeneJEPA 正式训练仅使用：

```Plain Text
Tahoe training pool 的固定25% shard subset
843 / 3372 shards
```

因此需要进一步确认：

> 这个25% subset 是否虽然数据量很大，但某些 biological context 覆盖不足。
> 
> 

这里不能直接问：

```Plain Text
Tahoe 中有没有 HLCA 的 Dendritic / AT2 / EC arterial
```

因为 Tahoe 与 HLCA 的细胞体系并不完全对应。

更合理的 audit 是比较：

```Plain Text
完整 Tahoe training pool
vs
当前固定25% subset
```

检查：

```Plain Text
cell line 数量
每个 cell line 的 cell 数
drug / perturbation 数量
每个 perturbation 的 cell 数
cell line × perturbation coverage
```

从而判断：

> 固定25% subset 是否存在明显 sampling imbalance。
> 
> 

这项分析目前还没有执行。

---

### 当前 Benchmark 已完成状态

截至目前，以下工作已经完成：

```Plain Text
✅ 完整 HLCA Core 下载
✅ raw expression 确认
✅ HLCA → GeneJEPA 27,402 genes 100% mapping
✅ 固定18-class benchmark cohort
✅ 578,572 cells 全量纳入
✅ 固定 80/20 stratified split
✅ Epoch24 embedding
✅ Epoch25 embedding
✅ Epoch29 embedding
✅ 三个 embedding 完整性检查
✅ strict Logistic Regression protocol 固定
✅ LR convergence 测试
✅ Epoch24 full linear probe
✅ Epoch25 full linear probe
✅ Epoch29 full linear probe
✅ 三 checkpoint downstream 对比
✅ Epoch25 confusion matrix
✅ Epoch25 per-cell predictions 保存
✅ Epoch25 Top-3 misclassification 输出
```

正式 checkpoint benchmark 的核心结论：

```Plain Text
Epoch25
```

同时具有：

```Plain Text
最低的 JEPA val_loss
+
最高的 Accuracy
+
最高的 Macro-F1
+
最高的 Balanced Accuracy
```

在目前比较的三个 late\-stage checkpoint 中，Epoch25 是当前最佳模型。

---

### 当前主要 Benchmark 文件

#### Benchmark cohort

```Plain Text
benchmark_data/hlca/
benchmark_ann_level3_all18_seed42.csv
```

#### Embeddings

```Plain Text
benchmark_results/hlca18/
epoch24_all18_embeddings.npy
epoch24_all18_rows.csv

epoch25_all18_embeddings.npy
epoch25_all18_rows.csv

epoch29_all18_embeddings.npy
epoch29_all18_rows.csv
```

#### Linear probe

```Plain Text
benchmark_results/hlca18/
epoch24_linear_probe_full.csv
epoch25_linear_probe_full.csv
epoch29_linear_probe_full.csv
```

#### Epoch25 confusion analysis

```Plain Text
benchmark_results/hlca18/
epoch25_predictions_full.csv

epoch25_confusion_matrix_raw_full.csv

epoch25_confusion_matrix_row_normalized_full.csv

epoch25_top3_misclassifications_full.csv

epoch25_confusion_matrix_row_normalized_full.png
```

#### 主要脚本

```Plain Text
make_hlca_benchmark_split.py

extract_hlca_embeddings.py

merge_hlca_embeddings.py
merge_hlca_embeddings_epoch24.py
merge_hlca_embeddings_epoch29.py

run_hlca_linear_probe.py
run_hlca_linear_probe_epoch24.py
run_hlca_linear_probe_epoch29.py
run_hlca_linear_probe_epoch25_confusion.py
```

---

### 当前 Benchmark 方法的限制

目前需要明确保留以下限制。

#### 当前是 cell\-level split

当前：

```Plain Text
train / test
```

来自同一个 HLCA pool，并不是 donor\-disjoint。

所以目前主要适合：

> checkpoint representation comparison
> 
> 

而不是严格证明：

> GeneJEPA 可以泛化到完全未见过的新 donor。
> 
> 

---

#### 类别严重不平衡

例如：

```Plain Text
Macrophages
111,844 cells

Lymphatic EC mature
4,001 cells
```

差距非常大。

主 benchmark 故意没有加：

```Plain Text
class_weight="balanced"
```

因此小类别 Recall 较低可能有一部分来自 classifier 的 class imbalance。

但为了保持 checkpoint 比较公平，目前不修改主 benchmark protocol。

---

#### Tahoe 与 HLCA 存在 domain shift

GeneJEPA 的 representation 是在 Tahoe\-100M 上学习的。

HLCA 则是正常人肺组织 atlas。

因此当前 benchmark 本身包含：

```Plain Text
pretraining dataset
→ external biological domain
```

的 transfer。

这意味着一些 cell type 表现不佳不一定只由模型结构导致，也可能与 pretraining coverage 有关。

---

#### 当前只比较了三个 checkpoint

目前结论只能写成：

> Epoch24 / Epoch25 / Epoch29 三个 checkpoint 的 JEPA val\_loss ranking 与 downstream linear\-probe ranking 一致。
> 
> 

暂时不应该扩大成：

> 所有训练阶段中 val\_loss 与 biological representation quality 都严格相关。
> 
> 

---

### 下一步 Benchmark 待办

目前优先级较高的后续工作包括：

#### A\. Tahoe 25% subset coverage audit

检查：

```Plain Text
full Tahoe training pool
vs
25% frozen subset
```

在：

```Plain Text
cell line
drug
perturbation
cell line × drug
```

上的覆盖情况。

目的是回答：

> 当前25%训练子集是否存在明显的数据覆盖偏差。
> 
> 

---

#### B\. 利用 HLCA hierarchy 做 coarse\-to\-fine benchmark

HLCA 本身已经提供：

```Plain Text
ann_level_1 = 4 classes
ann_level_2 = 11 classes
ann_level_3 = 25 classes
```

当前正式实验使用：

```Plain Text
ann_level_3 → 筛成18类
```

后续可以在同一批 embedding 上增加：

```Plain Text
ann_level_1 linear probe
ann_level_2 linear probe
ann_level_3 linear probe
```

检查 representation 是否呈现：

```Plain Text
粗粒度 cell lineage
比较容易识别

↓  

细粒度 cell subtype
逐渐更难识别
```

这可以帮助判断：

> GeneJEPA 学到的是不是一种由粗到细的 biological hierarchy。
> 
> 

---

#### C\. 更严格的 donor\-disjoint benchmark

如果后续需要评估 external generalization，而不仅仅是 checkpoint quality，可以进一步：

```Plain Text
按 donor 分割 train / test
```

保证 test donor 完全未参与 probe training。

---

#### D\. 可选增加 Epoch19 / Epoch22

如果希望更加完整地研究：

```Plain Text
JEPA val_loss
vs
downstream embedding quality
```

可以继续补：

```Plain Text
Epoch19
Epoch22
```

形成更多 checkpoint 时间点，而不只比较 Epoch24 / 25 / 29。

---

### 当前 Benchmark 总结

当前这套 Benchmark 的完整逻辑可以概括为：

```Plain Text
Tahoe-100M 25% subset
↓
训练 GeneJEPA
↓
得到多个 checkpoint
↓
冻结 checkpoint
↓
使用完全独立的 HLCA Core
↓
raw counts
↓
统一 GeneJEPA gene vocabulary
↓
统一 GeneJEPA preprocessing
↓
EMA Teacher
↓
768-d cell embedding
↓
固定 HLCA 18-class train/test split
↓
严格线性 Logistic Regression
↓
Accuracy
Macro-F1
Balanced Accuracy
↓
比较 Epoch24 / Epoch25 / Epoch29
```

目前结果：

```Plain Text
Epoch25
```

在：

```Plain Text
JEPA validation objective
```

和：

```Plain Text
external downstream linear probe
```

两个角度上均为三个 checkpoint 中最佳。

因此现阶段可以认为：

> **本次训练得到的 GeneJEPA embedding 确实包含可被线性读取的 cell\-type biological information；在测试的三个 late\-stage checkpoint 中，Epoch25 的 representation quality 最好。**
> 
> 

与此同时，confusion matrix 显示：

> **不同 cell type 的线性可分性并不均匀，一些主要类别已经形成明显结构，而部分稀有类别、免疫亚型和 endothelial subtype 仍然较难区分。**
> 
> 

后续重点将从：

```Plain Text
“这个 benchmark 能不能跑？”
```

转向：

```Plain Text
“为什么某些类别表现较弱？”
```

以及：

```Plain Text
“25% Tahoe pretraining subset 的 biological coverage 是否足够均衡？”
```



![epoch25\_test\_balanced800\_tsne\.png](图片和附件/epoch25_test_balanced800_tsne.png)

![epoch25\_test\_balanced800\_umap\.png](图片和附件/epoch25_test_balanced800_umap.png)



### 直接用 LR 预测18个细胞分类

只用了 **20,000 个训练细胞 \+ 5,000 个测试细胞**，直接拿 `adata.X` 的 27,402 个基因表达做 LR，就已经得到：

而且几乎所有18个类别都非常高，连一些 GeneJEPA embedding 很难分的类别也明显改善。例如 Dendritic cells 的 F1 已经有 `0.8221`，EC arterial 是 `0.8976`，Lymphatic EC mature 是 `0.9859`。

并且这个 raw\-expression LR 还没有收敛。

![img\_v3\_02153\_5507d34f\-2c5e\-476d\-9a34\-5f548891cc2g\.jpg](图片和附件/img_v3_02153_5507d34f-2c5e-476d-9a34-5f548891cc2g.jpg)

![img\_v3\_02154\_c7e79b75\-401b\-4572\-9b0b\-9c21347cc9dg\.jpg](图片和附件/img_v3_02154_c7e79b75-401b-4572-9b0b-9c21347cc9dg.jpg)



**\-\-\-**



## 扰动模块工作的启动：从“表征是否有用”进入“能否预测扰动后状态”

在完成 GeneJEPA 第一阶段训练以及 HLCA 外部 benchmark 后，下一阶段工作开始从：



“GeneJEPA embedding 是否包含有意义的生物学信息”



转向：



“GeneJEPA embedding 能否作为细胞状态表示，进一步学习药物扰动后的状态变化”。



当前确定的总体路线不是直接让 GeneJEPA 输出差异表达基因，而是把整个虚拟细胞流程拆成两个阶段：



Tahoe 原始单细胞表达

↓

冻结 GeneJEPA Epoch25 EMA Teacher

↓

768\-d cell embedding

↓

STATE\-style State Transition 模型

↓

预测药物处理后的 768\-d cell\-state population

↓

后续再考虑从 latent 恢复到 expression / DES



因此当前扰动模块的核心问题变成：



1. GeneJEPA latent 中是否真的保留了药物扰动信号；

2. control population 与 treated population 应如何构造；

3. STATE\-style set\-to\-set 模型能否在 GeneJEPA latent 空间中学习状态转移；

4. 如何设计没有明显信息泄漏的 train / validation / test；

5. 如何大规模、可恢复地提取 Experiment 1 所需的 GeneJEPA embedding。

这一阶段没有重新训练 GeneJEPA。第一阶段模型固定使用当前最佳：



scjepa\-epoch=25\-val\_loss=0\.179\.ckpt



并使用 frozen EMA Teacher 作为 downstream encoder。



**\-\-\-**



## Tahoe\-100M 全量扰动数据结构重新梳理

开始做扰动模块后，首先重新扫描并梳理 Tahoe\-100M 全量数据，而不是只观察单个 parquet shard。



确认表达主表包含：



3,388 个 parquet shards

95,624,334 cells



后续扰动模块使用的关键 metadata 包括：



- drug

- sample

- plate

- cell\_line\_id

- BARCODE\_SUB\_LIB\_ID

- moa\-fine

- canonical\_smiles

- pubchem\_cid



剂量信息不直接存放在巨大的 expression parquet 主表中，而通过 sample metadata 与 sample 关联。



全量检查确认：



active drugs = 379



剂量固定为：



0\.05 μM

0\.5 μM

5\.0 μM



control 为：



DMSO\_TF



其中需要特别避免把：



Trametinib \(DMSO\_TF solvate\)



因为字符串中包含 DMSO\_TF 而误识别成 control。



当前对 perturbation condition 的理解逐步冻结为：



单细胞

↓

sample

↓

plate × cell\_line × drug × dose

↓

matched plate × cell\_line DMSO

↓

跨 plate 的 drug × dose × cell\_line biological condition



parquet shard 本身只是物理存储单位，不属于生物实验条件，后续不作为模型 feature。



**\-\-\-**



## 从“cell pair”纠正为 population\-level set\-to\-set pairing

Tahoe 中 control cell 与 treated cell 之间没有物理的一一配对关系。



因此不能构造：



control cell A

→

treated cell A



这种假想 cell\-level supervision。



当前模型定义改为：



control population

\+

drug / dose condition

→

predicted treated population



即：



Z\_control\_set \[S, 768\]

\+

perturbation

→

STATE\-style ST

→

Z\_pred\_set \[S, 768\]



再与真实：



Z\_treated\_set \[S, 768\]



进行 population\-level distributional comparison。



set size 第一版固定为：



S = 256



这一步也明确了一个重要概念：



tahoe\_set\_to\_set\_pairs\.csv



不是“细胞配对表”，而是 condition\-level 可训练 pool 的索引地图。



全量 condition census 得到：



65,218 个 candidate condition rows



其中满足：



control ≥ 256

treated ≥ 256



的 eligible conditions 为：



56,993



因此 Experiment 1 的正式 universe 最终以这 56,993 个 eligible\_S256 conditions 为基础。



**\-\-\-**



## Experiment 0：在正式训练 ST 之前先审计 GeneJEPA latent 是否适合做 perturbation prediction

在直接投入几十小时甚至更长的 Experiment 1 之前，先增加一个小规模：



Experiment 0 latent suitability audit



目的不是训练模型，而是回答：



GeneJEPA 的 768\-d latent 中到底有没有可检测的 perturbation signal？



主要审计内容包括：



1. signed latent numerical statistics；

2. latent anisotropy / common component；

3. effective rank；

4. DMSO null shift；

5. DMSO → drug shift；

6. repeated subsampling stability；

7. plate6 / plate14 repeated high\-dose consistency；

8. dose\-associated geometry；

9. ΔZ residual geometry；

10. cross\-cell\-line drug identity signal。

第一版 cohort 固定：



3 个 cell lines

×

5 个 drugs

×

4 个 condition points

×

5 repeated subsamples



其中 4 个 condition points 为：



0\.05 μM / plate4

0\.5 μM / plate5

5\.0 μM / plate6

5\.0 μM / plate14 replicate



同时增加 DMSO\-control → DMSO\-control null。



**\-\-\-**



## Experiment 0 cohort 设计修正：DMSO null 与 repeated subsampling

Experiment 0 初始设计中曾有两个需要修正的问题。



### DMSO null 不能从同一个 pooled DMSO population 同时抽 source 和 target



最初：



DMSO sample A \+ B pooled

↓

source / target 都从同一个 pooled population 抽样



这种设计主要测到：



sampling noise



而不能很好体现：



sample\-to\-sample baseline variation。



因此修改为：



同 plate

\+

同 cell line

\+

两个独立 DMSO samples



即：



DMSO sample A

→

DMSO sample B



直接扫描 Tahoe 后确认：



24 / 24 个所需 DMSO sample × cell\-line group

全部满足 S ≥ 256



最小单 sample cell 数：



1,379



因此无需 fallback 到 pooled null。



**\-\-\-**



### bootstrap 改为 set 内无放回 repeated subsampling



初始设计曾使用：



bootstrap\_with\_replacement



但当前目标是模拟 STATE 实际输入的真实 cell set，因此最终改为：



repeated\_subsampling\_without\_replacement



规则：



每个 S=256 set 内

同一个 physical cell 不能重复



不同 repeat 之间

允许部分重合



每个 condition 固定 5 个 seed 重复。



因此最终 cohort：



300 条 perturbation rows

\+

60 条 DMSO\-null rows

=

360 rows



每行 source / target 都各自包含 256 个真实 physical cells。



**\-\-\-**



## Experiment 0 客观选择 cell lines / drugs，并明确 dose 与 plate 混杂

为了避免手工挑选“看起来效果好的”条件，Experiment 0 的 3 个 cell lines 与 5 个 drugs 使用固定客观规则选择。



cell line 需要满足：



- 三档剂量完整；

- 5 μM plate6 / plate14 replicate 存在；

- control / treated capacity 均满足 S=256。

随后按照 eligible drug coverage 与 worst\-case capacity 排序。



drug 选择同时考虑：



- 三个选中 cell lines 中都可用；

- dose / replicate 条件完整；

- MOA 不是 unclear；

- 尽量覆盖不同 MOA；

- 按 robust capacity 选择。

最终 cell lines：



CVCL\_0546

CVCL\_0459

CVCL\_0480



drugs：



Artesunate

Trimetrexate

Retinoic acid

Clonidine \(hydrochloride\)

Tucidinostat



同时明确 Tahoe 当前 dose design 存在：



0\.05 μM = plate4

0\.5 μM  = plate5

5\.0 μM  = plate6 / plate14



因此 dose 与 plate 存在设计混杂。



后续 dose\-associated geometry 只能描述：



“不同 dose/plate condition 的 latent shift 差异”



不能直接解释为纯 causal dose\-response。



**\-\-\-**



## Experiment 0 stable cell\-index plan

在正式跑 Epoch25 embedding 前，没有直接按临时扫描行号保存 cell。



最终稳定 locator 定义为：



project\-relative parquet shard path

\+

row\_group\_index

\+

row\_index\_in\_row\_group



并根据 locator 生成稳定 cell\_id。



BARCODE\_SUB\_LIB\_ID 只作为 metadata 保存，没有被假设为全数据集唯一 physical cell ID。



sampling 使用：



sha256\_bottom\_k\_without\_replacement\_v1



即：



stable cell\_id

\+

固定 seed

→

SHA\-256 排序

→

取 bottom 256



因此 sampling：



- 不依赖 parquet 扫描顺序；

- 不依赖线程数；

- 不依赖一次运行产生的临时全局 row number。

最终：



360 pair rows

720 source/target side sets

184,320 total cell slots



每个 side\-set：



exactly 256 unique cells



source / target physical overlap：



max = 0



所有 set 的 unique cell union：



129,061 cells



其中：



DMSO unique = 62,804

treated unique = 66,257



因此只需要对 129,061 个 unique physical cells 各提一次 embedding，而不是对 184,320 个使用槽位重复推理。



**\-\-\-**



## Experiment 0 Epoch25 GeneJEPA embedding extraction

正式 extraction 前先做 CPU preprocessing dry\-run。



32 / 32 cells 通过：



- stable locator 回读一致；

- sentinel 每 cell 只处理一次；

- gene mapping 正常；

- unmapped genes = 0；

- log1p 一次；

- Tahoe global mean/std normalization 一次；

- normalized values 全 finite；

- inverse recovery max error ≈ 6\.1e\-05。

随后做 Epoch25 GPU smoke：



256 cells

batch\_size = 64

EMA Teacher

eval mode



输出：



shape = \[256, 768\]

dtype = float32

finite = true



negative\-coordinate ratio ≈ 48\.3%



同一批输入重复推理：



max difference = 0



之后正式完成：



129,061 × 768



Experiment 0 embedding cache。



embedding 与：



embedding\_index



严格一一对应。



完整性检查确认：



- shape / dtype 正确；

- all finite；

- embedding\_index 连续；

- 每个 set 恰好 256 个 cell；

- source / target 无 physical overlap；

- 所有 set shift / residual 分析可由原始 embedding 重建。

**\-\-\-**



## Experiment 0 latent geometry：发现 GeneJEPA 空间存在很强 common component

Experiment 0 首先确认 GeneJEPA 输出是：



signed latent



negative coordinate ratio：



约 48\.3%



因此后续 STATE/ST 的最终 latent output：



不能使用 ReLU

不能使用 Softplus

不能做非负 clipping



否则会改变 GeneJEPA latent space 的基本定义。



进一步分析发现 raw latent 中存在很强 common component：



median raw cell norm

≈ 39\.56



audit cohort mean vector norm

≈ 39\.14



median centered cell norm

≈ 4\.22



cohort mean vector 解释 raw second moment

≈ 98\.3%



raw pairwise cosine median

≈ 0\.987



centered pairwise cosine median

≈ \-0\.058



centered PCA entropy effective rank

≈ 10\.73



top\-10 PCs explain centered variance

≈ 89\.8%



说明：



GeneJEPA 的 768\-d raw latent 虽然维度很高，但不同 cell 共享一个非常大的公共方向，真正区分 cell state 的变化主要位于相对较小的 centered / residual space 中。



因此后续 perturbation analysis 不能只看 raw cosine。



**\-\-\-**



## Experiment 0 perturbation signal 结果：PASS WITH CAUTION

DMSO null shift median：



≈ 0\.477



drug perturbation shift median：



≈ 0\.531



60 个 perturbation conditions 中：



47 / 60

≈ 78\.3%



drug shift 大于 matched DMSO null。



说明 GeneJEPA latent 中确实保留了一定 perturbation signal。



但 repeated S=256 subsampling 下：



drug ΔZ repeat cosine median

≈ 0\.396



说明 signal 存在，但 population sampling noise 也不低。



5 μM plate6 / plate14 independent replicate residual cosine：



median ≈ 0\.416



不同 drug、不同 cell line 的稳定性差异也比较明显。



实验还尝试了：



ΔDrug \- ΔDMSO



作为 diagnostic residual。



结果这种 DMSO residualization 并没有整体改善 repeated shift stability，因此最终结论为：



DMSO\-subtracted residual

只保留为诊断分析



不作为 Experiment 1 训练 target 或固定 preprocessing。



Experiment 0 最终状态：



PASS WITH CAUTION



即：



GeneJEPA latent 中存在可学习的 perturbation information，

但 signal\-to\-noise 并不强，正式 ST 必须与 identity / simple baseline 做严格比较。



**\-\-\-**



## 区分两种 residual：diagnostic residual 与 architecture residual

这一阶段特别明确了两个经常混淆的 residual。



A\. Diagnostic DMSO residual：



ΔDrug \- ΔDMSO



这是 Experiment 0 中用于分析 plate / sample baseline 的诊断量。



当前结果不支持把它作为正式 ST target。



**\-\-\-**



B\. Architecture output\-space residual：



ΔZpred = ST\_delta\(\.\.\.\)

Zpred = raw\_Zctrl \+ ΔZpred



这是模型结构本身的 residual parameterization。



它的目的不是减 DMSO，而是让模型学习：



control state

→

perturbation\-induced change



因此虽然 diagnostic DMSO residual 没有带来整体改善，仍然保留 architecture residual 作为正式 ST ablation。



**\-\-\-**



## Experiment 1：正式 State Transition 输入输出定义

Experiment 1 第一版固定：



control GeneJEPA latent：

\[B, 256, 768\]



perturbation condition：

drug \+ dose



target：

treated GeneJEPA latent

\[B, 256, 768\]



模型：



STATE\-style set\-to\-set State Transition



输出仍在同一个 GeneJEPA 768\-d latent space。



第一版不做：



expression decoder

DES head

batch predictor

confidence token

gene\-count output



先回答一个更基础的问题：



给定 basal/control population

\+

drug / dose



能否预测 treated latent population？



**\-\-\-**



## Experiment 1 train / validation / test split

正式 split key 固定为：



\(cell\_line\_id, drug\)



原因：



如果只按单个 condition row 随机 split，

同一个 cell\_line × drug 的不同 dose / plate 很容易同时出现在 train 和 test，

造成组合信息泄漏。



因此一个 edge 的所有：



dose

plate

sample

plate6 / plate14 replicate



必须进入同一 split。



正式 eligible universe：



56,993 conditions



对应：



17,174 个 \(cell\_line\_id, drug\) edges



split：



train ≈ 80%

val   ≈ 10%

test  ≈ 10%



seed = 42



结果：



train edges = 13,740

val edges   = 1,717

test edges  = 1,717



并约束：



val/test drug 必须在 train 的其他 cell line 出现过



val/test cell line 必须在 train 的其他 drug 出现过



因此 Experiment 1 第一版测试的是：



seen drug

\+

seen cell\-line context

→

unseen cell\_line × drug combination



不能声称：



unseen\-drug zero\-shot generalization。



同时检查：



edge overlap = 0

condition overlap = 0

plate6/plate14 replicate leakage = 0



**\-\-\-**



## Experiment 1 perturbation representation：379\-d drug one\-hot \+ standardized log\-dose

第一版为了减少变量，没有直接引入 SMILES、MOA、PubChem 或 ESM。



正式 perturbation vector 固定为：



379\-d drug one\-hot

\+

1\-d standardized log10\(dose\_uM\)



总维度：



pert\_dim = 380



dose：



0\.05

0\.5

5\.0 μM



标准化 statistics 只根据 train eligible condition rows 拟合。



同一个 set 的 256 cells：



复制同一个 380\-d perturbation vector。



第一版明确不输入：



cell\-line ID

plate

sample

MOA

SMILES

PubChem

ESM



cell context 由 control population 本身提供。



**\-\-\-**



## STATE/ST 对 GeneJEPA signed latent 的兼容性改造

官方 STATE 的 embedding residual 定义与当前 GeneJEPA 需要并不完全一致。



因此基于官方：



StateTransitionPerturbationModel



做最小修改，而不是重写新模型。



共同路径：



raw control \[B,256,768\]

↓

basal encoder



perturbation \[B,256,380\]

↓

perturbation encoder



两者进入官方 Transformer / Llama backbone

↓

ST hidden

↓

project\_out

↓

768\-d output



正式保留两种 ablation。



ST\-A absolute：



Zpred = project\_out\(ST\_hidden\)



ST\-R output\-space residual：



DeltaZpred = project\_out\(ST\_hidden\)



Zpred = raw\_Zctrl \+ DeltaZpred



特别注意：



ST\-R 不使用官方原 embedding branch 的：



project\_out\(ST\_hidden \+ control\_hidden\)



而是把 residual 定义在 GeneJEPA raw output space。



同时新增：



final\_activation = identity



避免官方逻辑在 embedding output 上使用 ReLU。



hidden\-layer GELU / ReLU 可以保留，但最终 768\-d output 必须允许 signed values。



**\-\-\-**



## STATE 独立环境与真实 full\-stack smoke

由于 GeneJEPA 与当前 STATE 的 Python package requirement 存在冲突，最终没有直接升级已有 GeneJEPA environment。



环境拆分为：



Environment A：

GeneJEPA

负责 Tahoe preprocessing \+ Epoch25 embedding extraction



Environment B：

STATE

负责读取 768\-d latent \+ ST training



STATE 使用独立：



C:\\SH\\AIVC\\state\-main\\\.venv



并确认：



Python 3\.11

CUDA available

torch

transformers

geomloss

hydra / omegaconf

peft

arc\-state editable local source



均可以正常工作。



随后不再使用 fake geomloss / Identity backbone，而是真正使用：



official Llama backbone

\+

geomloss SamplesLoss\(loss="energy"\)

\+

forward

\+

backward



单卡 full\-stack smoke 通过：



- output shape 正确；

- Energy finite；

- gradients finite；

- signed output 保留；

- ST\-R output\-space residual contract exact；

- 10\-step fixed\-batch overfit loss 明显下降。

**\-\-\-**



## 双卡 DDP smoke 与 STATE batch\-size throughput sweep

STATE 正式训练仍计划使用两张 RTX A6000。



双卡继续沿用此前 WSL/NCCL workaround：



NCCL\_CUMEM\_ENABLE=0

NCCL\_CUMEM\_HOST\_ENABLE=0



真实双卡 DDP 已验证：



- 两 rank 均有负载；

- parameter sync max error = 0；

- loss / gradients finite；

- checkpoint pipeline 可工作。

随后为了提高资源利用率，对：



batch\_size\_per\_rank =

4

8

16

32

64



进行了单卡与双卡 throughput sweep。



64 / GPU 时：



global batch = 128



双卡 throughput scaling 最稳定：



ST\-A

≈ 1\.90–1\.92 × single GPU



ST\-R

≈ 1\.89–1\.92 × single GPU



而每张 A6000 reserved VRAM 仍只有约 12\.5 GiB。



因此当前 Experiment 1 第一版工程默认：



64 / GPU

2 GPUs

global batch = 128



这一选择是：



throughput / resource\-utilization decision



不是：



“global batch 128 已被科学证明是优化最优值”。



ST\-A 与 ST\-R 后续必须使用相同 global batch、split、training budget 和 metrics 保证公平。



注意：



这里的 STATE training batch=64/GPU



与后面 GeneJEPA embedding extraction 使用的 batch=64



只是数值恰好相同，属于两个完全不同的 batch 概念。



**\-\-\-**



## Experiment 1 full embedding cache 规模设计

最初评估过 treated condition 分别缓存：



256

512

1024



个 cells。



最终考虑：



cap=256

几乎没有 target population 重抽样空间



cap=1024

embedding cache 成本显著增加



因此 treated 第一版冻结：



cap = 512 per eligible condition



同时对 DMSO control 不再使用 cap=512，而是：



all eligible DMSO



原因：



同一个 DMSO pool 会被大量 drug conditions 重复作为 basal population 使用，

全量保留 DMSO 能明显增加 control population diversity，

而额外空间成本相对于 treated cache 较小。



最终正式 v1 cache policy：



treated cap=512

\+

all eligible DMSO



精确规模：



eligible conditions = 56,993



treated cells = 28,639,959



DMSO cells = 2,199,130



total unique cells = 30,839,089



float32 \[N,768\] payload：



≈ 88\.231 GiB



这一 cache policy 已冻结。



**\-\-\-**



## full\-cache locator / worker plan

正式 30\.84M cells 仍然不能依赖临时扫描 row number。



继续沿用 stable locator：



shard\_path

\+

row\_group\_index

\+

row\_index\_in\_row\_group



并建立：



global embedding\_index



全局覆盖：



0

→

30,839,088



正式 plan 被 deterministic 地分成两个 independent workers。



worker0：



15,442,261 cells



worker1：



15,396,828 cells



检查：



worker overlap = 0

union = all

missing embedding\_index = 0

duplicate embedding\_index = 0



两个 worker 不使用 DDP/NCCL。



逻辑为：



GPU0

→ worker0

→ independent part cache



GPU1

→ worker1

→ independent part cache



最后：



按 global embedding\_index

scatter / merge



**\-\-\-**



## 正式 full\-cache extractor：增加 resume、progress 和完整性保护

考虑到 30\.84M\-cell extraction 预计是几十小时级任务，不能再采用“进程中断就全部重来”的简单脚本。



正式 worker 增加：



\.npy\.partial

completed bitmap

atomic progress JSON

runtime extraction manifest

file lock



并记录：



checkpoint SHA\-256

plan SHA\-256

preprocessing provenance

processed / remaining / failed

current shard / row group

throughput

GPU runtime statistics



重要原则：



“\.npy 文件存在”

或

“文件大小正确”



不能证明 extraction 已完成。



因为 memmap output 在创建时就会预分配完整 shape。



真正进度由：



committed prefix

\+

completed bitmap

\+

progress manifest

\+

finite / provenance audit



共同定义。



**\-\-\-**



## resume correctness 与 merge rehearsal

正式长跑前使用真实 formal worker 做了在线验收。



每个 worker 先运行一部分：



worker0 = 9,216 committed cells

worker1 = 9,216 committed cells



total = 18,432



然后主动停止 / restart。



resume audit 确认：



- 已 committed embedding bytes 不变化；

- completed bitmap 不变化；

- resume 从 committed position 后继续；

- committed cells 不重复计算；

- failed attempts = 0；

- permanent failed cells = 0。

随后提前做小型 merge/scatter rehearsal：



worker0 part

\+

worker1 part

↓

global embedding\_index scatter



检查：



missing = 0

duplicate = 0

finite = 100%



并随机抽 cell 重新运行 Epoch25 inference，与 cache row 对比。



在相同 extraction context 下：



max difference = 0



说明：



resume

\+

worker\-local part

\+

global scatter



这套流程工程上已经跑通。



**\-\-\-**



## GeneJEPA full extraction batch probe：发现 batch64 与 batch128 embedding 不一致

因为正式 30M extraction 很耗时，为了提速，曾短测试：



GeneJEPA extraction batch\_size = 64



与：



batch\_size = 128



吞吐结果：



batch64

≈ 50\.39 cells/s



batch128

≈ 60\.65 cells/s



batch128 约快：



20%



原本看起来可以直接用更大 batch 提速。



但是对相同 cells 做 cross\-batch numerical comparison 后发现：



cross\_batch\_allclose = false



max absolute difference：



≈ 1\.07154



这明显大于普通 1e\-5 / 1e\-4 级 floating\-point rounding noise。



因此没有把正式 cache 从 64 改到 128。



正式 Experiment 0 的所有 129,061 embeddings 本身就是使用：



batch64



提取的。



其中：



signed ratio

common component

effective rank

DMSO null

drug shift

repeat stability

plate replicate

residual geometry



全部基于 batch64 latent。



为了保持：



Experiment 0

→

Experiment 1



使用同一个 extraction representation protocol，



当前 formal worker 也继续冻结：



GeneJEPA extraction batch = 64



并禁止：



一部分 cache 用64

另一部分 cache 用128



混合在同一个 latent array 中。



**\-\-\-**



## 对“batch64 是否就是唯一正确 embedding”的重新认识

batch64 当前能够证明的是：



1. preprocessing 正确；

2. checkpoint 正确；

3. EMA Teacher / eval 正确；

4. 相同 batch64 context 重复推理结果一致；

5. Experiment 0 与 Experiment 1 extraction protocol 一致。

但它还不能证明：



batch64

=

GeneJEPA 理论上唯一正确的 cell embedding。



理想情况下，一个没有设计跨\-cell interaction 的 cell encoder 应满足：



同一个 cell

\+

同一个 checkpoint

\+

同一个 preprocessing



无论放在：



batch1

batch16

batch64

batch128



都应得到同一个 embedding，

最多存在极小 numerical error。



当前已经发现：



batch64 \!= batch128



因此真正的问题不是：



“到底64还是128更好？”



而是：



“为什么同一个 cell 的 embedding 会对 inference batch context 敏感？”



这可能涉及：



padding / mask

BF16 autocast

不同 tensor shape 下的 CUDA kernel

attention numerical path

或其他 batch\-context\-dependent implementation detail



目前尚未定位根因。



**\-\-\-**



## 当前需要建立 batch\-invariance reference audit

为了判断当前 GeneJEPA batched inference 是否符合模型数学定义，下一步应建立一个 reference inference。



推荐 reference：



single cell

\+

FP32

\+

EMA Teacher

\+

eval

\+

完全相同 preprocessing



即：



batch=1 FP32



作为数值参考尺。



随后固定同一批 cells，分别测试：



batch1

batch8

batch16

batch32

batch64

batch128



并分别比较：



FP32

vs

BF16 autocast



至少统计：



max absolute difference

mean absolute difference

RMSE

L2 distance

raw cosine

centered\-space cosine



还应增加 neighbour\-invariance test：



固定 cell A



batch64：

A \+ neighbour group 1



batch64：

A \+ completely different neighbour group 2



如果仅更换同 batch 内其他 cells，

cell A 的 embedding 仍明显变化，



则说明当前 inference 存在不应有的 batch\-context dependence。



判断逻辑：



如果：



batch1 FP32

≈ batch64 FP32

≈ batch128 FP32



但 BF16 不一致，



则主要是 mixed\-precision / numerical\-path 问题。



如果：



FP32 下也明显不一致，



则应优先检查 batched forward / padding / attention 实现，

而不是继续进行 30M\-cell long extraction。



**\-\-\-**



## 截至 2026\-09\-07 的扰动模块当前状态

当前已完成：



Tahoe full perturbation metadata audit          ✅



condition\-level set\-to\-set pairing census      ✅



S=256 eligible condition universe              ✅



Experiment 0 cohort                            ✅



DMSO sample A → B null                         ✅



repeated subsampling without replacement       ✅



stable physical cell locator                   ✅



Experiment 0 129,061\-cell embedding cache      ✅



Experiment 0 latent geometry audit             ✅



drug / null perturbation signal audit          ✅



Experiment 0 status                            ✅ PASS WITH CAUTION



Experiment 1 edge split                        ✅



379\-d drug one\-hot \+ 1\-d log\-dose             ✅



STATE GeneJEPA signed\-latent compatibility      ✅



ST\-A absolute                                  ✅



ST\-R output\-space residual                     ✅



real Llama \+ real Energy full\-stack smoke      ✅



2\-GPU STATE DDP                                ✅



STATE throughput sweep                         ✅



ST engineering default 64/GPU                  ✅



full cache policy                              ✅

treated cap512 \+ all eligible DMSO



30,839,089\-cell locator/index plan             ✅



dual independent extraction worker             ✅



resume correctness                             ✅



merge/scatter rehearsal                        ✅



formal cache committed cells                   18,432



full 30\.84M cache extraction                   ⏸ 尚未完成



STATE/ST formal training                       ⏸ 尚未开始



GeneJEPA batch invariance                      ⚠️ 新发现问题，待定位



**\-\-\-**



## 当前阶段最重要的结论

这周扰动模块工作已经从最初的：



“GeneJEPA 后面能不能接一个扰动模型？”



逐步推进为：



Tahoe 全量 perturbation metadata

↓

population\-level control / treated pairing

↓

Experiment 0 latent suitability audit

↓

确认 latent 中存在但并不非常强的 perturbation signal

↓

设计 Experiment 1 unseen combination split

↓

冻结 drug \+ dose representation

↓

改造官方 STATE 适配 signed GeneJEPA latent

↓

打通真实 Llama \+ Energy \+ backward

↓

打通 2×A6000 DDP

↓

冻结 treated cap512 \+ all DMSO cache

↓

实现 30\.84M\-cell resumable dual\-GPU extraction

↓

在正式长跑前发现 batch64 / batch128 embedding 不一致



当前新的直接问题已经不再是：



STATE 能不能运行



而是：



> 在继续提取约 30M GeneJEPA embeddings 之前，先确认 GeneJEPA 的 batched inference 是否满足应有的 batch invariance，并建立一个可解释的 reference embedding protocol。
> 
> 



只有这一点确认后，后续 30\.84M cache 才能不仅是“工程上可复现”，还能够更有把握地认为是在执行正确的 encoder forward 定义。



**\-\-\-**



## 扰动模块阶段的一句话总结

截至 2026\-09\-07，已经完成从 GeneJEPA representation 到 STATE\-style perturbation prediction 的主要数据、模型与工程框架搭建，并通过 Experiment 0 验证 GeneJEPA latent 中存在可检测的药物扰动信号；Experiment 1 的 split、380\-d perturbation encoding、ST\-A/ST\-R、双卡 DDP 以及 30\.84M\-cell full\-cache 方案均已完成设计和工程验收。



当前唯一需要在 full\-cache 长跑前优先解决的新问题是：



> GeneJEPA 同一 cell 在 batch64 与 batch128 inference 下出现不可忽略的 embedding 差异，需要通过 batch1 FP32 reference 与 batch\-invariance audit 判断其来源，并最终冻结真正可靠的 production inference protocol。
> 
> 





**\-\-\-**



## 2026\-09\-08～2026\-09\-11：Experiment 1 从 full cache 长跑进入正式模型比较

截至 2026\-09\-07 时，扰动模块已经完成：



- Experiment 0 latent suitability audit；

- Experiment 1 split / perturbation encoding；

- STATE\-style ST\-A / ST\-R 接入；

- 双卡 smoke / throughput；

- 30\.84M\-cell full\-cache extraction plan 与 resume 机制；

但正式 full cache 尚未完成，ST 正式训练也尚未开始。



接下来几天的工作重点发生了明显变化：



> 从“把数据、模型和工程框架搭起来”，转向“完成全量 latent cache → 建立正式 baseline → 完成 ST 正式训练与 test → 给出可以汇报的最终五模型比较”。
> 
> 



这段工作最终把 Experiment 1 从工程准备阶段完整推进到了：



```Plain Text
final comparison complete
```



**\-\-\-**



## GeneJEPA batch64 / batch128 问题的阶段性处理决定

此前发现：



```Plain Text
same cells
batch64 inference
vs
batch128 inference
```



存在不可忽略的数值差异，早期 probe 中记录过：



```Plain Text
cross_batch_max_abs_difference ≈ 1.07154
```



但需要注意：



这个值只是被观测到的最大单坐标差异，



并不能直接说明：



```Plain Text
所有 embedding 都相差 1.07
```



也不能仅凭一个 max absolute difference 推断整个 embedding distribution 的差异程度。



原计划曾考虑继续做：



```Plain Text
batch1 FP32 reference
batch8 / 16 / 32 / 64 / 128
FP32 vs BF16
neighbour invariance
```



来系统定位 batch dependence。



后续与技术顾问讨论后，当前项目决定没有继续把这一问题作为 Experiment 1 的阻塞项。



当前冻结原则变为：



1. 正式 cache 全部继续使用已经验证的 `batch_size=64`；

2. 不把 batch64 / batch128 混合到同一个正式 cache；

3. 不对 embedding 做人为 round / truncate；

4. 保留原始 float32 cache；

5. batch128 只保留为后续数值稳定性研究问题，不影响当前扰动模块主线继续推进。

因此当前更准确的表述是：



> batch64 是本项目当前统一、可复现、与 Experiment 0 一致的 production extraction protocol；当前没有证明它是数学上唯一正确的 embedding，也没有完成完整的 batch\-invariance 理论归因。
> 
> 



**\-\-\-**



## 30,839,089\-cell GeneJEPA full cache 最终完成

随后继续运行两张 GPU 的 independent extraction workers。



正式 policy 保持：



```Plain Text
treated cap = 512 per eligible condition
+
all eligible DMSO
```



总规模：



```Plain Text
treated cells = 28,639,959
DMSO cells    =  2,199,130
total         = 30,839,089
```



两个 worker 最终均完成自己的完整 plan：



```Plain Text
worker0 = 15,442,261 cells
worker1 = 15,396,828 cells
```



运行尾部曾出现 GPU monitor / `nvidia-smi` timeout 一类异常记录，但正式 extraction manifest 最终确认：



```Plain Text
worker0 status = finished
worker1 status = finished

remaining_cells = 0
permanent_failed_cells = 0
```



因此这些尾部监控异常没有造成 embedding 缺失。



最终两份 worker\-local cache 通过：



```Plain Text
global embedding_index
```



scatter / merge 为正式 merged cache：



```Plain Text
results/
tahoe_experiment1_cache_cap512_all_dmso_embeddings.npy
```



正式 shape：



```Plain Text
[30,839,089, 768]
```



dtype：



```Plain Text
float32
```



正式 embedding payload：



```Plain Text
≈ 88.231 GiB
```



正式 SHA\-256：



```Plain Text
f31a7b6fc6b665656c398cbb10ed3591b86fd7bb64dd2b26a3cc0b759f3f202b
```



全局 merge audit 确认：



```Plain Text
missing embedding_index   = 0
duplicate embedding_index = 0
worker overlap            = 0
all finite                = true
```



至此：



> Experiment 1 所需的 30\.84M\-cell GeneJEPA latent cache 正式完成。
> 
> 



**\-\-\-**



## 正式 merged\-cache consumer / DataLoader audit

full cache 完成后，没有马上训练 baseline 或 ST，而是先审计：



```Plain Text
formal merged cache
→ condition / control pool
→ global embedding_index
→ S=256 set
→ model input
```



继续复用：



```Plain Text
TahoeExperiment1LatentSetDataset
```



正式 DataLoader 输出冻结为：



```Plain Text
ctrl_cell_emb [B,256,768]
pert_cell_emb [B,256,768]
pert_emb      [B,256,380]
```



审计确认：



```Plain Text
train conditions = 45,652
val conditions   =  5,657
test conditions  =  5,684
```



所有抽查 split 均满足：



- control / treated set 都严格为 256 cells；

- set 内无放回；

- embedding\_index 合法且与 merged cache row 对应；

- latent 为 raw signed float32；

- all finite；

- 不做 centering；

- 不做 whitening；

- 不做 L2 normalization；

- 不做 DMSO residualization；

- perturbation 为 379\-d drug one\-hot \+ 1\-d train\-only standardized log10 dose；

- drug one\-hot 恰好一个 1；

- split 与冻结的 `(cell_line_id, drug)` edge split 一致。

consumer audit 最终：



```Plain Text
PASS
```



且没有发现阻塞下一阶段的问题。



**\-\-\-**



## 冻结 Experiment 1 正式 evaluation sampling protocol

为了让：



```Plain Text
B0
B1
B2
ST-A
ST-R
```



最后可以严格 paired comparison，正式冻结统一 evaluation protocol。



参数：



```Plain Text
S = 256

repeat_count = 5
base_seed = 42
repeat_epochs = [0,1,2,3,4]

shuffle = false
drop_last = false
```



这里的 `repeat_epochs=[0,1,2,3,4]` 只是 evaluation repeat ID，



不是训练 epoch。



每个模型都必须使用完全相同的：



```Plain Text
condition_id
repeat_epoch
control sampled indices
treated sampled indices
```



正式 test：



```Plain Text
5,684 conditions
× 5 repeats
=
28,420 condition-repeat rows
```



最终 comparison unit 为：



```Plain Text
(cell_line_id, drug) edge
```



共：



```Plain Text
1,717 edges
```



reproducibility audit 确认：



- 两次独立构造 Dataset 的 sampled indices 完全一致；

- set 内无放回；

- 不同 repeat 可以重叠；

- B0/B1/B2/ST\-A/ST\-R 共享同一套 sampling basis。

这一阶段解决了一个很重要的问题：



> 后续模型差异不能来自“不同模型刚好抽到了不同 test cells”。
> 
> 



**\-\-\-**



## B0 Identity baseline：建立 no\-change 下限

第一个正式 baseline 定义：



```Plain Text
B0 Identity

Zpred = Zctrl
```



即：



> 假设药物没有造成任何变化，直接把 control population 当作 predicted treated population。
> 
> 



对完整 test：



```Plain Text
5,684 conditions
× 5 repeats
=
28,420 raw rows
```



计算：



```Plain Text
EnergyDistance(Zctrl, Ztrue)
```



Energy 使用当前统一实现：



```Plain Text
geomloss.SamplesLoss(
    loss="energy",
    blur=0.05
)
```



不训练任何参数。



**\-\-\-**



## B0 aggregation bug：plate6 / plate14 只有 5\.0 μM 才能作为 biological replicate 合并

B0 第一版 aggregation 中发现：



当前 helper 会把任意同：



```Plain Text
(cell_line_id, drug, dose_uM)
```



下同时出现的 plate6 / plate14 都当成 biological replicate。



这造成：



2 个 Adagrasib 0\.05 μM group



也被错误合并。



正式实验规则实际上是：



```Plain Text
ONLY IF

dose_uM == 5.0
AND
plate6 + plate14 both exist

→ pair / average as one biological replicate unit
```



因此做了最小修正：



- 不重新计算 28,420 条 raw Energy；

- raw CSV 保持不变；

- 只重新做 aggregation；

- 其他 dose 不特殊合并 plate6 / plate14。

修正后：



```Plain Text
high-dose plate6/plate14 replicate groups = 397
final edges = 1717
```



B0 final edge Energy：



```Plain Text
mean   = 0.0359202899
median = 0.0329825719
p05    = 0.0234919167
p95    = 0.0572128169
```



至此 B0 正式冻结。



**\-\-\-**



## B1 之前先做 train→test drug\-dose coverage audit

B1 的目标是建立一个极简单但有生物意义的 baseline：



```Plain Text
drug + dose
→
平均扰动方向
```



正式预测：



```Plain Text
Zpred
=
Zctrl
+
mean_delta(drug, dose)
```



在计算 mean delta 前，先审计：



> test 中每一个 `(drug,dose)` 是否在 train 中有 exact match。
> 
> 



train：



```Plain Text
45,652 conditions
379 drugs
1,132 unique (drug,dose)
```



test：



```Plain Text
5,684 conditions
377 drugs
1,123 unique (drug,dose)
1,717 edges
```



结果：



```Plain Text
5,684 / 5,684 test conditions exact covered
1,717 / 1,717 test edges all-dose covered

coverage = 100%
missing combinations = 0
```



因此 B1 不需要任何：



```Plain Text
fallback
nearest dose
global drug mean
```



这保证了 B1 的定义非常干净。



**\-\-\-**



## 构建 B1 train\-only condition shift 与 mean\-delta reference

B1 没有直接使用随机 S=256 来拟合 mean shift。



正式 train condition shift 定义为：



```Plain Text
Delta_condition
=
centroid(all cached treated cells)
-
centroid(all cached matched control cells)
```



即每一个 train condition：



- treated centroid 使用该 condition 在正式 cache 中全部 cached treated cells；

- control centroid 使用匹配 DMSO pool 的全部 cached control cells；

- 不做 S=256 subsampling；

- 不按 cell count 给 condition 加权。

全部：



```Plain Text
45,652 train conditions
```



生成：



```Plain Text
condition_shift [45652,768]
float32
```



然后按 exact：



```Plain Text
(drug, dose_uM)
```



分组，对 condition shift 做等权 arithmetic mean：



```Plain Text
mean_delta [1132,768]
float32
```



每个 train condition 对组均值权重固定为：



```Plain Text
1
```



不做 cell\-count weighting。



正式 mean\-delta norm sanity：



```Plain Text
min    ≈ 0.05324
mean   ≈ 0.29285
median ≈ 0.27484
p05    ≈ 0.11221
p95    ≈ 0.52384
max    ≈ 0.90763
```



test exact mapping：



```Plain Text
5,684 / 5,684
= 100%
```



**\-\-\-**



## B1 正式 test：平均 drug\-dose shift 已经能优于 B0

正式 B1 prediction：



```Plain Text
Zpred
=
Zctrl
+
mean_delta(drug,dose)[None,:]
```



对同一 condition 内全部 256 control cells broadcast 同一个 768\-d shift。



test sampling 与 B0 完全一致。



最终 edge\-level：



```Plain Text
B0 mean Energy = 0.0359202899
B1 mean Energy = 0.0335430391
```



ratio\-of\-means improvement：



```Plain Text
≈ 6.62%
```



逐 edge：



```Plain Text
B1 beats B0
=
1117 / 1717
≈ 65.06%
```



正式 mean per\-edge EnergyGain：



```Plain Text
≈ 4.33%
```



这里专门明确了两个统计口径：



A\. ratio of means：



```Plain Text
(mean_ref - mean_candidate) / mean_ref
```



B\. mean per\-edge EnergyGain：



```Plain Text
mean(
    (ref_edge - candidate_edge) / ref_edge
)
```



二者不是同一个统计量，后续汇报不能混为一个百分比。



B1 的结果说明：



> GeneJEPA latent 中存在一部分可以跨 held\-out cell\-line×drug 组合迁移的 drug\-dose average shift。
> 
> 



但 B1 仍在约 35% edges 上不如 B0，因此仍有明显 context\-specific 建模空间。



**\-\-\-**



## B2 Pooled MLP：先做 training\-contract audit

在开始 B2 前，先检查项目中是否已经存在一个可直接复用的 B2。



高层定义已经确定为：



```Plain Text
control_context = mean(control_set)  # 768
+
perturbation                         # 380
↓
MLP
↓
Delta_pred                           # 768

Zpred = raw_Zctrl + Delta_pred
```



但 static audit 发现：



项目中并没有一个已经冻结、可以直接拿来训练的 B2 implementation。



已有：



- `PseudobulkPerturbationModel`

- `EmbedSumPerturbationModel`

- GeneJEPA `LinearProbeMLP`

- generic STATE MLP

都不能直接等同于当前 Experiment 1 的 B2。



因此最初 B2 training\-contract 状态为：



```Plain Text
INCOMPLETE / NOT READY
```



需要单独冻结实现。



**\-\-\-**



## B2\-v1：冻结 pooled MLP 并尝试直接使用 set\-level Energy 训练

B2\-v1 最终冻结为：



```Plain Text
input:
768 control mean
+
380 perturbation
=
1148
```



MLP：



```Plain Text
1148
→ 1024
→ GELU
→ 1024
→ GELU
→ 768
```



要求：



```Plain Text
dropout = 0
normalization = none
output activation = identity
```



最后 Linear：



```Plain Text
weight = 0
bias   = 0
```



因此初始化时：



```Plain Text
Delta_pred = 0
Zpred = Zctrl
```



严格等价于 B0 initialization。



B2\-v1 训练 objective 最初为了尽可能与 ST 一致，冻结为：



```Plain Text
set-level Energy
```



即：



```Plain Text
Zpred
vs
真实 treated set
```



直接优化 Energy distance。



单卡 / 双卡 implementation smoke 均 PASS。



**\-\-\-**



## B2\-v1 正式训练暴露问题：Energy training 太慢

B2\-v1 随后启动正式 full training。



虽然模型只有约：



```Plain Text
3,013,376 parameters
```



远小于 ST，



但训练 loss 需要直接对：



```Plain Text
[B,256,768]
vs
[B,256,768]
```



计算 set\-level Energy，



正式运行速度仍然很慢。



历史 B2\-v1 最终运行到大约：



```Plain Text
14 epochs
4,984 optimizer steps
```



后停止。



这些 checkpoint / history 被保留作为历史 artifact，



但不作为最终 baseline scientific result。



这一阶段促使我们重新思考：



> B2 的作用只是提供一个“比 B1 更有 context、但比 ST 更简单”的 pooled baseline，没有必要为了强行统一训练 objective 而让 baseline 本身变成昂贵长跑。
> 
> 



**\-\-\-**



## B2\-v2：把训练目标改成 condition\-shift MSE

为了让 B2 成为真正可执行的 lightweight context baseline，



最终保留 B2 architecture 不变，只修改训练 supervision。



正式 target 直接复用 B1 已经构建好的：



```Plain Text
Delta_condition
=
treated centroid
-
matched control centroid
```



训练：



```Plain Text
Delta_pred
=
MLP(
  concat(
    mean(ctrl_cell_emb),
    perturbation
  )
)

loss
=
MSE(
    Delta_pred,
    Delta_condition
)
```



但 validation / checkpoint selection 仍然使用正式：



```Plain Text
set-level Energy
```



因此 B2\-v2：



```Plain Text
training objective = centroid-shift MSE
validation metric  = formal edge-level Energy
```



正式双卡：



```Plain Text
2 × RTX A6000
128 / GPU
global batch = 256
```



optimizer：



```Plain Text
AdamW
lr = 3e-4
weight_decay = 1e-4
clip = 1.0
```



max epochs：



```Plain Text
30
```



early stopping：



```Plain Text
patience = 5
```



**\-\-\-**



## B2\-v2 正式训练与 checkpoint

B2\-v2 full training 最终：



```Plain Text
epochs completed = 16
optimizer steps  = 2,848

early stopping = true
best epoch = 10
```



epoch 0 val edge Energy：



```Plain Text
0.0344657347
```



best val edge Energy：



```Plain Text
0.0325107435
```



best checkpoint：



```Plain Text
results/
tahoe_experiment1_b2_v2_formal_checkpoints/
b2_v2_best.pt
```



SHA\-256：



```Plain Text
8d23da4e6760e1165eeab216eeb0cda22111cfcd735af4aa1884599209fbcdd3
```



正式确认：



- fresh initialization；

- 没有加载 B2\-v1 / smoke checkpoint；

- test 未用于 checkpoint selection。

**\-\-\-**



## B2\-v2 正式 test：context mean 确实提供额外信息

B2\-v2 best checkpoint 在 frozen test protocol 上正式评估。



最终：



```Plain Text
B0 mean Energy = 0.03592029
B1 mean Energy = 0.03354304
B2 mean Energy = 0.03273458
```



逐 edge：



```Plain Text
B2 beats B0
=
1286 / 1717
≈ 74.90%
```



```Plain Text
B2 beats B1
=
1022 / 1717
≈ 59.52%
```



因此可以得到阶段性结论：



> 当前 control population 的 context 确实提供了超过“drug\-dose 平均作用方向”之外的额外预测信息。
> 
> 



从能力阶梯上：



```Plain Text
B0
<
B1
<
B2-v2
```



已经成立。



同时从这一阶段开始，baseline ladder 被正式固定：



```Plain Text
B0 = no-change
B1 = drug-dose average shift
B2 = context-conditioned pooled shift model
```



**\-\-\-**



## ST 正式训练 readiness：第一次审计仍然 FAIL

B0/B1/B2 完成后，开始推进真正的 STATE\-style ST。



虽然此前已经：



- 打通 ST\-A；

- 打通 ST\-R；

- real Llama smoke PASS；

- real Energy backward PASS；

- 2\-GPU DDP PASS；

但正式 readiness audit 仍然给出：



```Plain Text
formal training readiness = FAIL
```



原因不是模型 branch 不可用，



而是正式 training contract 仍有大量工程配置没有完全冻结，例如：



- 精确正式 architecture；

- optimizer / LR；

- weight decay；

- gradient clipping；

- precision；

- training seed；

- training budget；

- early stopping；

- checkpoint selection；

- resume format；

- current merged\-cache Dataset → ST formal runner。

因此这个 FAIL 实际表示：



> “模型能跑”不等于“可以直接开始正式 scientific training”。
> 
> 



**\-\-\-**



## 冻结 ST v1 architecture 与 merged\-cache integration smoke

随后正式冻结第一版 ST architecture。



共同结构：



```Plain Text
input_dim  = 768
output_dim = 768
S          = 256
pert_dim   = 380
```



basal encoder：



```Plain Text
Linear(768,768)
```



perturbation encoder：



```Plain Text
Linear(380,768)
```



project\_out：



```Plain Text
Linear(768,768)
```



Transformer：



```Plain Text
LlamaBidirectionalModel

hidden_size         = 768
intermediate_size   = 3072

num_hidden_layers   = 8
num_attention_heads = 12
num_key_value_heads = 12
head_dim            = 64

max_position_embeddings = 256

attention_dropout = 0
hidden_dropout    = 0

layer_norm_eps = 1e-6
hidden_act     = silu

use_cache             = false
use_rotary_embeddings = false
```



总参数：



```Plain Text
101,560,320
```



trainable：



```Plain Text
76,984,320
```



A/R 唯一受控差异：



ST\-A：



```Plain Text
predict_residual = false

Zpred
=
project_out(ST_hidden)
```



ST\-R：



```Plain Text
predict_residual = true
residual_mode = output

Zpred
=
raw_Zctrl
+
project_out(ST_hidden)
```



随后直接使用当前正式 merged cache Dataset 做双卡 integration smoke。



结果：



```Plain Text
ST-A PASS
ST-R PASS
```



确认：



- forward / backward；

- real Energy；

- parameter update；

- DDP sync；

- fixed validation；

- checkpoint save/load；

全部可工作。



**\-\-\-**



## 正式 ST 训练工程配置重新审视：不再沿用“最简单 smoke 配置”

最初 integration smoke 的目的只是验证 plumbing，



其中：



```Plain Text
num_workers = 0
FP32 forward
batch 64/GPU
```



属于最保守的工程设置。



在真正准备正式长跑时，重新审查并决定不把 smoke 的“最简单配置”原样拿去训练。



最终正式 v2 engineering config 冻结为：



DataLoader：



```Plain Text
num_workers = 2 / rank
total workers = 4

pin_memory = true
persistent_workers = false
prefetch_factor = 2

GPU transfer:
non_blocking = true
```



之所以：



```Plain Text
persistent_workers = false
```



是为了确保每个新 epoch 创建新的 worker process，



能正确看到：



```Plain Text
dataset.set_epoch(epoch)
```



后的动态 set redraw。



**\-\-\-**



## ST v2 precision / accumulation / DDP 正式配置

正式模型 forward 使用：



```Plain Text
BF16 autocast
```



但 Energy metric / loss 明确使用：



```Plain Text
FP32
```



即：



```Plain Text
Zpred_for_energy = Zpred.float()
Ztrue_for_energy = Ztrue.float()
```



然后再进入：



```Plain Text
geomloss.SamplesLoss(
    loss="energy",
    blur=0.05
)
```



同时：



```Plain Text
GradScaler = none
TF32 = false
```



正式 batch：



```Plain Text
batch_size_per_gpu = 64
world_size = 2
```



raw global microbatch：



```Plain Text
128
```



gradient accumulation：



```Plain Text
2
```



effective global batch：



```Plain Text
64 × 2 × 2
=
256
```



每个 accumulation window：



microbatch 1：



```Plain Text
DDP no_sync()
```



microbatch 2：



```Plain Text
normal synchronized backward
```



每个 microbatch backward：



```Plain Text
loss_for_backward
=
raw Energy / 2
```



只在 accumulation boundary：



```Plain Text
clip
optimizer.step()
zero_grad()
```



gradient clip：



```Plain Text
1.0
```



optimizer：



```Plain Text
AdamW
lr = 1e-4
weight_decay = 1e-4
scheduler = none
seed = 42
```



**\-\-\-**



## ST 正式训练为什么没有加入 DeepSpeed

准备正式训练时也讨论过：



```Plain Text
DeepSpeed
```



它确实可以支持：



- BF16；

- accumulation；

- clipping；

- ZeRO；

- distributed training。

但当前 ST：



```Plain Text
≈ 101.6M parameters
```



而两张 A6000：



```Plain Text
48 GB / GPU
```



final\-config smoke 中实际 peak allocated 只有约：



```Plain Text
8.2 GiB / rank
```



显存压力非常小。



因此最终决定：



> 不为了“可能有一点速度收益”引入新的 DeepSpeed dependency、sharded checkpoint、resume 复杂度。
> 
> 



正式训练继续使用：



```Plain Text
native PyTorch DDP
```



这一决定本质上遵守：



```Plain Text
YAGNI
```



和：



> 在科学实验已经接近收尾时，尽量减少新的工程变量。
> 
> 



**\-\-\-**



## TensorBoard 正式接入 ST training

为了像 GeneJEPA 第一阶段一样实时观察：



```Plain Text
train
validation
gradient
throughput
VRAM
```



ST 正式 runner 增加 TensorBoard。



只允许：



```Plain Text
rank0
```



写入。



正式 tag 包括：



```Plain Text
train/energy_step
train/energy_epoch

val/condition_energy
val/edge_energy

train/lr

train/grad_norm_before_clip
train/grad_norm_after_clip

system/conditions_per_second
system/peak_allocated_gib
system/peak_reserved_gib

best/val_edge_energy
best/epoch
```



明确禁止：



```Plain Text
test/*
```



训练阶段只看：



```Plain Text
train
+
validation
```



不允许边训练边看 test。



最初 exact\-config smoke 第一次启动时，环境缺少 TensorBoard package，



留下过一个顶层：



```Plain Text
tensorboard.available = false
```



的 stale metadata。



安装依赖后 ST\-A / ST\-R variant\-level TensorBoard runtime audit 都已经：



```Plain Text
PASS
```



event file 与 required tags 均存在，



且：



```Plain Text
test tags = []
```



因此顶层旧字段只记录为 metadata reporting inconsistency，



不构成正式训练 blocker。



**\-\-\-**



## ST final\-config exact smoke：正式配置整体通过

最终正式配置没有直接进入长跑，



而是先用完全相同的 engineering config 做双卡 exact smoke。



两种 variant：



```Plain Text
ST-A
ST-R
```



均使用：



```Plain Text
2 × A6000
64/GPU
grad accumulation = 2
2 workers/rank
BF16 forward
FP32 Energy
native DDP
TensorBoard
```



smoke：



```Plain Text
10 microbatches
→
5 optimizer updates
```



确认：



- 4 个 DataLoader worker process 实际存在；

- pin memory 生效；

- epoch redraw 生效；

- BF16 path 实际生效；

- Energy 输入为 FP32；

- loss finite；

- gradient finite；

- no\_sync / sync 正确；

- DDP parameter sync exact；

- TensorBoard required tags 齐全；

- fixed validation reproducible；

- checkpoint save/load 正常。

peak allocated：



```Plain Text
ST-A ≈ 8.19 GiB
ST-R ≈ 8.16 GiB
```



global conditions/s 大约：



```Plain Text
ST-A ≈ 86.3
ST-R ≈ 84.5
```



至此正式训练配置冻结为：



```Plain Text
results/
tahoe_experiment1_st_training_protocol_v2.json
```



**\-\-\-**



## ST\-R 正式训练

正式训练首先运行 ST\-R。



train：



```Plain Text
45,652 conditions
```



val：



```Plain Text
5,657 conditions
```



每 epoch：



```Plain Text
356 microbatches
178 optimizer updates
45,568 train conditions consumed
84 conditions dropped
```



maximum：



```Plain Text
30 epochs
5,340 optimizer updates
```



validation 每 epoch 在 rank0 上完整执行：



```Plain Text
5,657 unique conditions exactly once
```



checkpoint selection：



```Plain Text
strict minimum val edge-level Energy
```



ST\-R 最终：



```Plain Text
epochs completed = 30
global step      = 5,340
stop reason      = max_epochs
early stopping   = false
```



epoch 0 val edge Energy：



```Plain Text
0.0408089293
```



best：



```Plain Text
epoch 26
val edge Energy = 0.0278065060
```



final epoch：



```Plain Text
0.0292983645
```



train Energy：



```Plain Text
epoch0  ≈ 0.20348
epoch29 ≈ 0.02991
```



总耗时：



```Plain Text
≈ 80.68 min
```



DDP parameter sync error：



```Plain Text
0.0
```



best checkpoint：



```Plain Text
results/
tahoe_experiment1_st_formal_checkpoints_v2/
st-r/best.pt
```



SHA：



```Plain Text
357fd6ec00473f5a6f2b82f5693c58365ea08f0af30500d092d354d0fbefd3ab
```



训练期间 test Dataset 从未构造。



**\-\-\-**



## ST\-A 正式训练

ST\-A 使用与 ST\-R 完全相同的：



- train / val；

- architecture；

- optimizer；

- precision；

- batch；

- accumulation；

- seed；

- training budget；

- validation；

- checkpoint rule。

唯一受控差异：



```Plain Text
absolute output
vs
output-space residual
```



ST\-A 最终：



```Plain Text
epochs completed = 30
global step      = 5,340
stop reason      = max_epochs
early stopping   = false
```



epoch 0 val edge Energy：



```Plain Text
0.1272491444
```



best：



```Plain Text
epoch 28
val edge Energy = 0.0210477382
```



final epoch：



```Plain Text
0.0217243596
```



train Energy：



```Plain Text
epoch0  ≈ 2.16691
epoch29 ≈ 0.02182
```



总耗时：



```Plain Text
≈ 82.17 min
```



DDP parameter sync error：



```Plain Text
0.0
```



best checkpoint：



```Plain Text
results/
tahoe_experiment1_st_formal_checkpoints_v2/
st-a/best.pt
```



SHA：



```Plain Text
9bd0f2719f42dac4fa5a9aabc4fd2bb242a442fb652ae90a8ee52fa54ca03652
```



同样：



```Plain Text
test Dataset never constructed during training
```



因此 ST\-A / ST\-R best checkpoint 都是在完全没有看 test 的前提下冻结的。



**\-\-\-**



## ST\-A / ST\-R validation 已经显示明显差异

两个 variant 的 best validation：



```Plain Text
ST-A = 0.02104774
ST-R = 0.02780651
```



ST\-A 相对 ST\-R 低约：



```Plain Text
24.3%
```



但此时仍然没有提前宣称：



```Plain Text
ST-A final winner
```



因为这仍然是 validation。



正式结论必须等：



```Plain Text
frozen best checkpoint
→
same formal test
```



完成后再判断。



**\-\-\-**



## ST 正式 raw test：两个 best checkpoint 使用完全相同的 test draws

随后只加载：



```Plain Text
ST-A best.pt
ST-R best.pt
```



运行 frozen test。



没有：



- optimizer；

- backward；

- train/val fitting；

- test\-time calibration；

- checkpoint reselection。

每个模型都得到：



```Plain Text
28,420 condition-repeat rows
```



对应：



```Plain Text
5,684 conditions
× 5 repeats
```



审计确认：



```Plain Text
ST-A row keys == ST-R row keys
sampling fingerprint exact match
all Energy finite
checkpoint epoch / SHA correct
parameters unchanged
```



raw mean Energy：



```Plain Text
ST-A ≈ 0.02129695
ST-R ≈ 0.02800525
```



这里仍然只是 condition\-repeat raw 层，



最终正式 comparison 继续使用 frozen biological aggregation。



**\-\-\-**



## ST 正式 aggregation

ST\-A / ST\-R raw test 使用与 B0/B1/B2 完全相同的 hierarchy：



```Plain Text
repeat
→ plate-level condition
→ biological replicate
→ (cell_line, drug, dose)
→ equal-dose average
→ (cell_line, drug) edge
```



特殊规则：



```Plain Text
only dose_uM == 5.0
and plate6 + plate14 both exist

→ paired as one biological replicate
```



最终两种 ST 都得到：



```Plain Text
plate-level conditions = 5,684
high-dose replicate groups = 397
dose-level units = 4,980
final edges = 1,717
```



不使用 cell\-count weighting。



**\-\-\-**



## Experiment 1 最终五模型正式比较

最终统一比较：



```Plain Text
B0
B1
B2-v2
ST-R
ST-A
```



所有模型：



- 相同 test edges；

- 相同 sampling basis；

- 相同 Energy implementation；

- 相同 aggregation rule；

- edge 数均为 1,717；

- no missing；

- all finite。

最终 mean edge\-level Energy：



```Plain Text
1. ST-A   0.02109734
2. ST-R   0.02795972
3. B2-v2  0.03273458
4. B1     0.03354304
5. B0     0.03592029
```



Energy 越低越好。



这形成了一个非常清晰的性能阶梯：



```Plain Text
B0
→ B1
→ B2-v2
→ ST-R
→ ST-A
```



**\-\-\-**



## 最终 ratio\-of\-means improvement

相对 B0：



```Plain Text
B1     +  6.62%
B2-v2  +  8.87%
ST-R   + 22.16%
ST-A   + 41.27%
```



相对 B2\-v2：



```Plain Text
ST-R
≈ 14.59% improvement
```



```Plain Text
ST-A
≈ 35.55% improvement
```



ST\-A 相对 ST\-R：



```Plain Text
≈ 24.54% improvement
```



这里统一使用：



```Plain Text
(reference mean - candidate mean)
/
reference mean
```



即：



```Plain Text
ratio-of-means improvement
```



不与 mean per\-edge EnergyGain 混淆。



**\-\-\-**



## 最终 paired edge 结果：ST\-A 的提升不是少数 edge 拉出来的

逐 edge comparison：



ST\-R vs B2\-v2：



```Plain Text
1599 / 1717
= 93.13%
```



ST\-A vs B2\-v2：



```Plain Text
1712 / 1717
= 99.71%
```



ST\-A vs ST\-R：



```Plain Text
1693 / 1717
= 98.60%
```



ST\-A vs B0：



```Plain Text
1704 / 1717
= 99.24%
```



ST\-A vs B1：



```Plain Text
1708 / 1717
= 99.48%
```



因此当前最重要的统计意义不是只有：



```Plain Text
mean Energy 更低
```



而是：



> ST\-A 在几乎所有 held\-out edges 上都取得了一致方向的改善。
> 
> 



**\-\-\-**



## 每个 edge 的全模型 winner

对每个 test edge：



```Plain Text
argmin(
  B0,
  B1,
  B2-v2,
  ST-R,
  ST-A
)
```



统计 winner。



结果：



```Plain Text
B0      9
B1      5
B2-v2   1
ST-R   21
ST-A 1681
ties     0
```



ST\-A：



```Plain Text
1681 / 1717
≈ 97.90%
```



的 edge 是五模型全局最优。



这进一步说明：



> ST\-A 的优势不是只存在于平均值，而是在绝大多数 individual held\-out combinations 上都成立。
> 
> 



**\-\-\-**



## 按 dose / cell line 分层后的稳定性

最终结果也按 dose 做了分层。



mean Energy：



```Plain Text
Dose 0.05 μM

B0     0.034228
B1     0.031852
B2     0.031248
ST-R   0.027105
ST-A   0.020866
```



```Plain Text
Dose 0.5 μM

B0     0.036143
B1     0.034172
B2     0.033024
ST-R   0.028024
ST-A   0.020673
```



```Plain Text
Dose 5.0 μM

B0     0.037108
B1     0.034341
B2     0.033726
ST-R   0.028580
ST-A   0.021666
```



ST\-A 相对 B2 的提升在三档 dose 均存在，



大约：



```Plain Text
0.05 μM ≈ 33.2%
0.5 μM  ≈ 37.4%
5.0 μM  ≈ 35.8%
```



最终 by\-cell\-line summary 共覆盖：



```Plain Text
47 cell lines
```



ST\-A 在每个 cell line 的 mean Energy 都是五模型最低。



**\-\-\-**



## ST\-A vs ST\-R：当前最干净的一组 architecture ablation

ST\-A 与 ST\-R：



- 使用同一 Dataset；

- 同一 train / val / test；

- 同一 8\-layer Llama backbone；

- 同一 optimizer；

- 同一 BF16 / FP32 Energy；

- 同一 batch / accumulation；

- 同一 seed；

- 同一 training budget；

- 同一 Energy loss；

- 同一 checkpoint selection；

- 同一 evaluation sampling。

唯一受控差异：



ST\-A：



```Plain Text
direct absolute prediction
```



ST\-R：



```Plain Text
raw output-space residual
```



因此：



```Plain Text
ST-A = 0.02110
ST-R = 0.02796
```



并且：



```Plain Text
ST-A beats ST-R
1693 / 1717
```



这一对照比：



```Plain Text
ST vs B2
```



更干净。



当前可以比较稳地得出：



> 在本 Experiment 1 的 GeneJEPA latent、数据和训练协议下，直接预测 absolute treated latent population 明显优于显式 output\-space residual parameterization。
> 
> 



**\-\-\-**



## ST\-A 与原 STATE 逻辑、ST\-R 与本项目扩展的关系重新明确

为了汇报时避免把“原版 / 扩展”说错，重新梳理：



ST\-A：



```Plain Text
predict_residual = false

Zpred
=
project_out(ST_hidden)
```



它对应的是 STATE\-style 的直接状态预测形式，



可以视为当前实验中更接近原始直接 prediction 的分支。



ST\-R：



```Plain Text
predict_residual = true
residual_mode = output

Zpred
=
raw_Zctrl
+
project_out(ST_hidden)
```



是本项目为了 GeneJEPA raw latent 设计的 output\-space residual 版本。



但需要注意：



官方 STATE 代码中本身并不是“完全没有 residual”。



官方某些 embedding residual 逻辑更接近：



```Plain Text
project_out(
  residual_hidden
  +
  control_hidden
)
```



即：



```Plain Text
hidden-space residual
```



而本项目为了让 residual 具有：



```Plain Text
GeneJEPA raw latent state change
```



的直接解释，新增：



```Plain Text
output-space residual
```



因此对外更准确的说法是：



> ST\-A 沿用 STATE\-style 的直接 prediction 思路；ST\-R 是本项目针对 GeneJEPA latent 增加的 raw output\-space residual ablation，而不是简单照搬官方 hidden\-space residual。
> 
> 



**\-\-\-**



## Energy distance 在 Experiment 1 中的角色重新梳理

正式 ST 训练和最终 test 都大量使用：



```Plain Text
Energy
```



因此在汇报准备阶段重新明确其含义。



Energy distance 比较的是：



```Plain Text
predicted cell population
vs
real treated cell population
```



而不是：



```Plain Text
pred cell #1
vs
true cell #1
```



原因是 Tahoe 中 control / treated cells 没有物理一一配对。



因此：



```Plain Text
MSE(cell_i, cell_i)
```



不是合理的 set\-to\-set supervision。



Energy 大致可以理解为：



```Plain Text
2 × cross-set distance
-
within-predicted distance
-
within-true distance
```



它同时考虑：



- 两个 population 彼此有多远；

- prediction 自己内部有多分散；

- truth 自己内部有多分散。

在 training 中：



```Plain Text
Energy = loss
```



在 validation / test 中：



```Plain Text
Energy = evaluation metric / prediction error
```



统一原则：



```Plain Text
lower is better
```



同时确认：



Energy distance 与 MMD 都属于比较两个分布 / 样本集合差异的方法，



但本项目实际实现是：



```Plain Text
geomloss SamplesLoss(loss="energy")
```



不是普通 kernel MMD。



**\-\-\-**



## 最终结果能够说明什么

Experiment 1 当前支持以下结论：



第一：



> GeneJEPA latent 中包含可被下游 perturbation predictor 利用的扰动相关信息。
> 
> 



如果 latent 完全没有 downstream 可用信息，



则从 B0 → B1 → B2 → ST 不应形成如此清晰、稳定的性能提升。



第二：



> control population 提供了超过 drug\-dose global average shift 的 context information。
> 
> 



依据：



```Plain Text
B2-v2 < B1
```



第三：



> 完整 set\-to\-set ST 能进一步提升 perturbation prediction。
> 
> 



依据：



```Plain Text
ST-R < B2-v2
ST-A < B2-v2
```



第四：



> 在当前 GeneJEPA latent 上，absolute treated\-state prediction 明显优于 output\-space residual。
> 
> 



依据：



```Plain Text
ST-A < ST-R
```



且：



```Plain Text
98.60% edges
```



方向一致。



**\-\-\-**



## 最终结果不能过度解释的地方

当前 test split 是：



```Plain Text
held-out (cell_line_id, drug) combinations
```



并且要求：



```Plain Text
test drug
在 train 的其他 cell line 出现过

test cell line
在 train 的其他 drug 出现过
```



因此正确表述：



```Plain Text
unseen cell-line × drug combination generalization
```



不能写成：



```Plain Text
unseen-drug generalization
```



也不能写成：



```Plain Text
unseen-cell-line generalization
```



更不能称为：



```Plain Text
zero-shot unseen drug
```



**\-\-\-**



## ST vs B2 的科学 caveat：不能把全部提升归因于 architecture

B2\-v2 与 ST 的正式训练 objective 不一致：



B2\-v2：



```Plain Text
centroid-shift MSE
```



ST：



```Plain Text
set-level Energy
```



同时 architecture 也不同：



B2\-v2：



```Plain Text
pooled context MLP
```



ST：



```Plain Text
set-to-set Transformer
```



因此：



```Plain Text
ST-A vs B2-v2
35.55% improvement
```



不能被严格解释为：



> “35\.55% 全部由 Transformer / set architecture 单独造成”。
> 
> 



更准确的科学表述：



> STATE\-style set\-to\-set perturbation model 在当前正式协议下优于 context\-conditioned centroid\-shift MLP baseline。
> 
> 



而：



```Plain Text
ST-A vs ST-R
```



因为其他训练条件一致，



是更干净的 architecture / parameterization ablation。



**\-\-\-**



## GeneJEPA 在当前实验中的角色边界

当前 Experiment 1 不能写成：



> “GeneJEPA 自己已经可以预测药物扰动。”
> 
> 



当前完整 pipeline 是：



```Plain Text
GeneJEPA
=
frozen cell-state encoder
```



```Plain Text
B1 / B2 / ST
=
downstream perturbation predictor
```



因此更准确的总结是：



> GeneJEPA latent 中保留了足以支持下游 perturbation prediction 和 held\-out combination generalization 的可利用信息。
> 
> 



最终 treated prediction 的能力来自：



```Plain Text
GeneJEPA representation
+
downstream perturbation model
```



而不是 GeneJEPA encoder 单独完成。



**\-\-\-**



## Experiment 1 最终正式产物

最终 comparison 已生成：



```Plain Text
results/
tahoe_experiment1_st_a_test_edge.csv

results/
tahoe_experiment1_st_r_test_edge.csv

results/
tahoe_experiment1_final_edge_comparison.csv

results/
tahoe_experiment1_final_model_summary.csv

results/
tahoe_experiment1_final_pairwise_summary.csv

results/
tahoe_experiment1_final_report_table.csv

results/
tahoe_experiment1_final_comparison_result.json

results/
tahoe_experiment1_final_comparison_handoff.md
```



并生成正式汇报图：



```Plain Text
tahoe_experiment1_final_model_energy.png

tahoe_experiment1_final_gain_vs_b2.png

tahoe_experiment1_final_st_a_vs_st_r.png
```



其中：



`final_model_energy`



用于展示五模型 mean edge Energy；



`final_gain_vs_b2`



用于展示 ST\-R / ST\-A 相对 B2\-v2 的提升；



`final_st_a_vs_st_r`



用于展示 paired edge 下 ST\-A 与 ST\-R 的一致性差异。



**\-\-\-**



## 截至 2026\-09\-11 的扰动模块最终状态

当前已完成：



```Plain Text
GeneJEPA Epoch25 frozen encoder                  ✅

Experiment 0 latent suitability audit            ✅
status = PASS WITH CAUTION

30,839,089-cell formal merged cache              ✅

merged-cache consumer / DataLoader audit         ✅

formal evaluation sampling protocol              ✅

B0 Identity                                      ✅

B1 drug-dose mean shift                          ✅

B2-v1 Energy training attempt                    ✅ historical / stopped

B2-v2 pooled MLP                                 ✅
formal train + val + test

ST formal readiness                              ✅

ST merged-cache integration                      ✅

ST v2 exact-config smoke                         ✅

ST-R formal train                                ✅
best epoch = 26

ST-A formal train                                ✅
best epoch = 28

ST-A / ST-R frozen test                          ✅

five-model final comparison                      ✅

Experiment 1 status                              ✅
final comparison complete

final report / figures / handoff                 ✅
```



当前已经不存在 Experiment 1 必须继续补跑的训练或 test blocker。



**\-\-\-**



## 2026\-09\-11 阶段性总总结

从整个扰动模块的发展过程看，这一阶段不是一开始就直接把 STATE 接在 GeneJEPA 后面训练。



实际路线经历了：



```Plain Text
Tahoe perturbation metadata audit
↓
population-level set-to-set condition definition
↓
Experiment 0 latent suitability audit
↓
确认 GeneJEPA latent 存在 perturbation signal
↓
冻结 unseen combination split
↓
冻结 380-d drug/dose representation
↓
适配 STATE 到 signed GeneJEPA latent
↓
ST-A / ST-R smoke
↓
设计 30.84M-cell full cache
↓
长跑 extraction + resume + merge
↓
正式 consumer / sampling protocol
↓
B0 no-change baseline
↓
B1 drug-dose average shift
↓
B2 context-conditioned pooled MLP
↓
ST-R / ST-A 正式训练
↓
统一 frozen test
↓
1,717 edges final comparison
↓
ST-A 最终胜出
```



最终结果：



```Plain Text
B0     0.03592
B1     0.03354
B2-v2  0.03273
ST-R   0.02796
ST-A   0.02110
```



当前最佳：



```Plain Text
ST-A
```



它相对：



```Plain Text
B0
改善 ≈ 41.27%
```



相对：



```Plain Text
B2-v2
改善 ≈ 35.55%
```



相对：



```Plain Text
ST-R
改善 ≈ 24.54%
```



并且：



```Plain Text
ST-A beats B2-v2
1712 / 1717 edges
= 99.71%
```



```Plain Text
ST-A is overall best
1681 / 1717 edges
= 97.90%
```



因此截至 2026\-09\-11，扰动模块已经从：



> “GeneJEPA latent 能不能拿来做 perturbation prediction？”
> 
> 



推进到了：



> “已经完成正式 baseline ladder、STATE\-style set\-to\-set training、held\-out combination test，并得到可汇报的稳定正结果。”
> 
> 



